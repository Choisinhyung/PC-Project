-- �α��� : ȸ������ �����ϴ� ���̺�
CREATE TABLE account (
             user_type varchar2(20) NOT NULL
           , user_name VARCHAR2(20) NOT NULL
           , user_id VARCHAR2(20) NOT NULL
           , user_pw VARCHAR2(20) NOT NULL
           , user_hour number NOT NULL
		       , user_minute number NOT NULL
           , CONSTRAINT account_t1_USER_id_PK PRIMARY KEY(user_id)
           );
                           
insert into account values ('manager', '���������Ŵ���','admin','kosa123',9999,30);
insert into account values ('member', '���±�','douzone','kosa123',0,30);
insert into account values ('nonmember', '��ȸ��', '12c', '1234', 2, 0);
                           
---- ��ǰ��� ���̺� 
drop table product;
CREATE TABLE product (
             pro_type varchar2(20) not null
           , pro_name VARCHAR2(20) NOT NULL
           , pro_price NUMBER NOT NULL
           , pro_nowNum VARCHAR2(20) NOT NULL
           , pro_salesNum number not null
           , pro_costprice number not null
           );

insert into product values('meal', '�ȼ�����', 2500, 100, 0, 700);
insert into product values('meal', '�Ŷ��', 3000, 100, 0, 800);
insert into product values('meal', '�����', 2800, 100, 0, 800);
insert into product values('meal', '¥�İ�Ƽ', 2600, 100, 0, 700);
insert into product values('meal', '���İ�Ƽ', 4500, 100, 0, 1200);
insert into product values('meal', '�ʱ���', 2900, 100, 0, 700);
insert into product values('meal', 'ġŲ����', 4500, 100, 0, 1500);
insert into product values('meal', '���Ը���', 5500, 100, 0, 2000);
insert into product values('meal', '�ܹ���', 4000, 100, 0, 1000);
insert into product values('meal', '�ֵ���', 3500, 100, 0, 1300);
insert into product values('meal', '����Ƣ��', 3100, 100, 0, 1500);
insert into product values('meal', '3��ī��', 7500, 100, 0, 3300);

insert into product values('drink', '�ݶ�', 2300, 100, 0, 500);
insert into product values('drink', '���̴�', 1700, 100, 0, 500);
insert into product values('drink', '�Ƹ޸�ī��', 4500, 100, 0, 1000);
insert into product values('drink', 'ȯŸ', 1500, 100, 0, 300);
insert into product values('drink', '��', 5000, 100, 0, 1200);

insert into product values('snack', '�ڰ�Ĩ', 1300, 100, 0, 200);
insert into product values('snack', '��¡��Ĩ', 1500, 100, 0, 300);
insert into product values('snack', '����Ĩ', 1700, 100, 0, 400);

---- ���� ī�� ���� ���̺�
CREATE table pay (
             cardType varchar2(20) not null
           , cardnum varchar2(20) not null
           , year number not null
           , month number not null
           , cvc number  not null
           , card_pw number not null
           );

insert into pay values ('VISA', '1234567887654321',22,12,123,1234);
insert into pay values ('MASTER', '8765432112345678',22,12,321,4321);