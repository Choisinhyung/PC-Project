package View;

import java.awt.Font;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

public class ChargeTime extends JFrame{
	public static String time;
	public ChargeTime(String name) {
	JFrame frame = new JFrame();
	frame.setTitle("시간 충전");
	frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // x 버튼 클릭시 해당 Frame 닫기
	frame.setBounds(800,400,320,300);    // 생성 위치(x,y) 창 넓이( x,y)
	frame.setLayout(null);		// 레이아웃 관리자를 설정하지 않음
	
	Panel panel = new Panel();
	panel.setBounds(0,0,160,300);
	panel.setLayout(null);
	
	Panel panel2 = new Panel();
	panel2.setBounds(160,0,160,300);
	panel2.setLayout(null);
	
	//------------------------------Radiobutton 부분--------------------
	
	JLabel lb_iteminfo = new JLabel("- 상품 정보 -");
	lb_iteminfo.setBounds(30,10,100,30);
	lb_iteminfo.setFont(new Font("Vernada", Font.BOLD, 15));
	panel.add(lb_iteminfo);
	
	JLabel lb_chargeprice = new JLabel("1000 원");
	lb_chargeprice.setBounds(45,50,100,30);
	lb_chargeprice.setFont(new Font("Vernada", Font.BOLD, 15));
	panel2.add(lb_chargeprice);
	
	JRadioButton btn_time1 = new JRadioButton(" 1시간 / 1000원 ",true);
	btn_time1.setBounds(10,40,140,30);
	panel.add(btn_time1);
	btn_time1.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			lb_chargeprice.setText("1000 원");
		}
	});
	
	JRadioButton btn_time2 = new JRadioButton(" 2시간 / 2000원 ",false);
	btn_time2.setBounds(10,70,140,30);
	panel.add(btn_time2);
	btn_time2.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			lb_chargeprice.setText("2000 원");
		}
	});
	
	JRadioButton btn_time3 = new JRadioButton(" 3시간 / 3000원 ",false);
	btn_time3.setBounds(10,100,140,30);
	panel.add(btn_time3);
	btn_time3.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			lb_chargeprice.setText("3000 원");
		}
	});
	
	JRadioButton btn_time6 = new JRadioButton(" 6시간 / 5000원 ",false);
	btn_time6.setBounds(10,130,140,30);
	panel.add(btn_time6);
	btn_time6.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			lb_chargeprice.setText("5000 원");
		}
	});
	
	JRadioButton btn_time12 = new JRadioButton(" 12시간 / 10000원 ",false);
	btn_time12.setBounds(10,160,140,30);
	panel.add(btn_time12);
	btn_time12.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			lb_chargeprice.setText("10000 원");
		}
	});
	
	JRadioButton btn_time60 = new JRadioButton(" 60시간 / 50000원 ",false);
	btn_time60.setBounds(10,190,140,30);;
	panel.add(btn_time60);
	btn_time60.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			lb_chargeprice.setText("50000 원");
		}
	});
	
	
	ButtonGroup bt_group = new ButtonGroup();
	bt_group.add(btn_time1);
	bt_group.add(btn_time2);
	bt_group.add(btn_time3);
	bt_group.add(btn_time6);
	bt_group.add(btn_time12);
	bt_group.add(btn_time60);
	
	
	
	JLabel lb_chargeinfo = new JLabel("- 결제 정보 -");
	lb_chargeinfo.setBounds(30,10,100,30);
	lb_chargeinfo.setFont(new Font("Vernada", Font.BOLD, 15));
	panel2.add(lb_chargeinfo);
	
	JButton btn_payment = new JButton("카드 결제");
	btn_payment.setBounds(20,100,110,55);
	btn_payment.setFont(new Font("Vernada", Font.BOLD, 15));
	panel2.add(btn_payment);
	btn_payment.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			frame.dispose();
			if(btn_time1.isSelected() == true) time = "1";
			else if(btn_time2.isSelected() == true) time = "2";
			else if(btn_time3.isSelected() == true) time = "3";
			else if(btn_time6.isSelected() == true) time = "6";
			else if(btn_time12.isSelected() == true) time = "12";
			else if(btn_time60.isSelected() == true) time = "60";
			Payment payment = new Payment(frame,"time",name,time);
		}
	});
	
	JButton btn_paymentcannel = new JButton("취소");
	btn_paymentcannel.setBounds(20,170,110,55);
	btn_paymentcannel.setFont(new Font("Vernada", Font.BOLD, 15));
	panel2.add(btn_paymentcannel);
	btn_paymentcannel.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			frame.dispose();
			
		}
	});
	
	
	
	
	
	frame.add(panel);
	frame.add(panel2);
	frame.setVisible(true);
	}
}
