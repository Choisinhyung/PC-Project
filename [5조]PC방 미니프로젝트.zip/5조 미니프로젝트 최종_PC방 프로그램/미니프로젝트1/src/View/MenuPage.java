package View;

import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import controller.MenuList;
import model.ProductListdata;

public class MenuPage extends JFrame{
	
	static int total_price = 0; //요거 추가
	
	private static GridBagLayout Gbag = new GridBagLayout(); ;
	private static GridBagConstraints gbc;
	
	
	private static JLabel lb;
	private static JLabel lb1;
	private static JLabel lb2;
	private static JLabel lb3;
	private static JLabel lb4;
	private static JLabel lb5;
	private static JLabel lb6;
	private static JLabel lb7;
	private static JLabel lb8;
	private static JLabel lb9;
	private static JLabel lb10;
	private static JLabel lb11;
	private static JLabel lb12;
	
	//-------checkBox------------
	
	private static JButton meal_bt1;
	private static JButton meal_bt2;
	private static JButton meal_bt3;
	private static JButton meal_bt4;
	private static JButton meal_bt5;
	private static JButton meal_bt6;
	private static JButton meal_bt7;
	private static JButton meal_bt8;
	private static JButton meal_bt9;
	private static JButton meal_bt10;
	private static JButton meal_bt11;
	private static JButton meal_bt12;
	
	private static JButton drink_bt1;
	private static JButton drink_bt2;
	private static JButton drink_bt3;
	private static JButton drink_bt4;
	private static JButton drink_bt5;
	
	
	private static JButton snack_bt1;
	private static JButton snack_bt2;
	private static JButton snack_bt3;
	
	
	//------------------------------------------------

	
	private static JPanel mealpanel;
	private static JPanel drinkpanel;
	private static JPanel Menuswitch;
	private static JPanel snackpanel;
	private static JPanel bottompanel;
	public static JLabel lb_totalprice1; // 요거 추가
	
	
	public static JTable ta_cart; //요거 추가
	public MenuPage(String name) {
		GridBagLayout Gbag =new GridBagLayout(); 

		JFrame frame = new JFrame();
		frame.setTitle("메뉴 주문");
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // x 버튼 클릭시 해당 Frame 닫기
		frame.setBounds(400,200,800,800);    // 생성 위치(x,y) 창 넓이( x,y)
		frame.setLayout(null);
		
		//----------------------메뉴판 바꾸는 부분---------------------------------
		Menuswitch = new JPanel();
		Menuswitch.setBounds(20,20, 800,60);
		Menuswitch.setLayout(null);
		
		JButton btn_meal = new JButton("식사");
		btn_meal.setBounds(0,0,245,60);
		Menuswitch.add(btn_meal);
		
		JButton btn_drink = new JButton("음료");
		btn_drink.setBounds(246,0,245,60);
		Menuswitch.add(btn_drink);
		
		JButton btn_snack = new JButton("간식");
		btn_snack.setBounds(492,0,245,60);
		Menuswitch.add(btn_snack);
		
		
		// --------------------------------- 메뉴판 부분-------------------------
		mealpanel = new JPanel();
		mealpanel.setBounds(20,100, 800,500);
		mealpanel.setLayout(Gbag);
		
		JScrollPane  mealscorll = new JScrollPane(mealpanel);
		mealscorll.setBounds(20, 100, 740, 400);
		
		drinkpanel = new JPanel();
		drinkpanel.setBounds(20,100, 800,500);
		drinkpanel.setLayout(Gbag);
		
		JScrollPane  Drinkscorll = new JScrollPane(drinkpanel);
		Drinkscorll.setBounds(20, 100, 740, 400);
		
		snackpanel = new JPanel();
		snackpanel.setBounds(20,100, 800,500);
		snackpanel.setLayout(Gbag);
		
		JScrollPane  snackscorll = new JScrollPane(snackpanel);
		snackscorll.setBounds(20, 100, 740, 400);
		
		bottompanel = new JPanel();
		bottompanel.setBounds(20,500, 800,300);
		bottompanel.setLayout(null);
		
		
		
		meal(mealpanel);
		drink(drinkpanel);
		snack(snackpanel);
	
		//---------------------Botton  부분------------------------------
		JLabel lb_cart = new JLabel("- 주문 목록 -",JLabel.CENTER);
		lb_cart.setFont(new Font("Vernada", Font.BOLD, 20));
		lb_cart.setBounds(0,0,300,70);
		bottompanel.add(lb_cart);
		
		JLabel lb_totalprice = new JLabel("- 총 금액 -",JLabel.CENTER);
		lb_totalprice.setFont(new Font("Vernada", Font.BOLD, 20));
		lb_totalprice.setBounds(390,0,300,70);
		bottompanel.add(lb_totalprice);
		
		
		//요거 바꿈
		lb_totalprice1 = new JLabel("0",JLabel.CENTER);
		lb_totalprice1.setFont(new Font("Vernada", Font.BOLD, 20));
		lb_totalprice1.setBounds(480,50,100,70);
		bottompanel.add(lb_totalprice1);
		
		JLabel lb_totalprice2 = new JLabel("원",JLabel.CENTER);
		lb_totalprice2.setFont(new Font("Vernada", Font.BOLD, 20));
		lb_totalprice2.setBounds(570,50,30,70);
		bottompanel.add(lb_totalprice2);
		
		
		//리스트 초기화 및 총금액 , 판매수량 알고리즘 필요 ***********************************************
		
		//요거 추가
		String [] column = {"상품명", "가격"};
		DefaultTableModel model=new DefaultTableModel(column,0);
		ta_cart  = new JTable(model);
		
		
		ta_cart.setBounds(10, 10, 200,200);
		ta_cart.setFont(new Font("Vernada", Font.BOLD, 15));
		JScrollPane tablescroll = new JScrollPane(ta_cart);
		tablescroll.setBounds(10, 70, 300,90);
		
		bottompanel.add(tablescroll);
		
		JButton btn_payment = new JButton("결제");
		btn_payment.setBounds(370,110,350,50);
		btn_payment.setFont(new Font("Vernada", Font.BOLD, 25));
		bottompanel.add(btn_payment);
		btn_payment.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				if(Integer.parseInt(lb_totalprice1.getText()) != Integer.parseInt("0") ) {
		               Payment payment = new Payment(ta_cart, lb_totalprice1, "item", name,"1");
		        }
			}
		});
		
		
		JButton btn_cancel = new JButton("나가기");
		btn_cancel.setBounds(570,200,150,40);
		btn_cancel.setFont(new Font("Vernada", Font.BOLD, 25));
		bottompanel.add(btn_cancel);
		
		JButton btn_listclear = new JButton("목록 초기화");
		btn_listclear.setBounds(10,180,300,60);
		btn_listclear.setFont(new Font("Vernada", Font.BOLD, 25));
		bottompanel.add(btn_listclear);
		
		
		btn_cancel.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				lb_totalprice1.setText("0");
				MenuList.initMenuList(ta_cart, lb_totalprice1);
				ProductListdata.menuNamePrice();
				frame.dispose();
			}
		});
		
		
		//요거 추가
		btn_listclear.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				lb_totalprice1.setText("0");
				MenuList.initMenuList(ta_cart, lb_totalprice1);
			}
		});
		//------------------------------------------------------------
		btn_meal.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
					mealscorll.setVisible(true);
					Drinkscorll.setVisible(false);
					snackscorll.setVisible(false);
			}
		});
		
		btn_drink.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				mealscorll.setVisible(false);
				Drinkscorll.setVisible(true);
				snackscorll.setVisible(false);
			}
		});
		btn_snack.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				mealscorll.setVisible(false);
				Drinkscorll.setVisible(false);
				snackscorll.setVisible(true);
			}
		});
		
		
		
		
		frame.add(mealscorll);
		frame.add(Drinkscorll);
		frame.add(snackscorll);
		frame.add(Menuswitch);
		frame.add(bottompanel);
		frame.setVisible(true);
	}
	
	public void meal(JPanel panel) {
//		String Path = "C:\\Users\\user\\Downloads\\라면.jfif";
		String Path = "./img/안성탕면.jpg";
		Image img = new ImageIcon(Path).getImage();
		img = img.getScaledInstance(150, 100, Image.SCALE_DEFAULT);
		ImageIcon icon = new ImageIcon(img);
		
		String Path2 = "./img/신라면.png";
		Image img2 = new ImageIcon(Path2).getImage();
		img2 = img2.getScaledInstance(150, 100, Image.SCALE_DEFAULT);
		ImageIcon icon2 = new ImageIcon(img2);
		
		String Path3 = "./img/진라면.jpg";
		Image img3 = new ImageIcon(Path3).getImage();
		img3 = img3.getScaledInstance(150, 100, Image.SCALE_DEFAULT);
		ImageIcon icon3 = new ImageIcon(img3);
		
		String Path4 = "./img/짜파게티.jfif";
		Image img4 = new ImageIcon(Path4).getImage();
		img4 = img4.getScaledInstance(150, 100, Image.SCALE_DEFAULT);
		ImageIcon icon4 = new ImageIcon(img4);
		
		String Path5 = "./img/스파게티.jpg";
		Image img5 = new ImageIcon(Path5).getImage();
		img5 = img5.getScaledInstance(150, 100, Image.SCALE_DEFAULT);
		ImageIcon icon5 = new ImageIcon(img5);
		
		String Path6 = "./img/너구리.jfif";
		Image img6 = new ImageIcon(Path6).getImage();
		img6 = img6.getScaledInstance(150, 100, Image.SCALE_DEFAULT);
		ImageIcon icon6 = new ImageIcon(img6);
		
		String Path7 = "./img/치킨마요.jfif";
		Image img7 = new ImageIcon(Path7).getImage();
		img7 = img7.getScaledInstance(150, 100, Image.SCALE_DEFAULT);
		ImageIcon icon7 = new ImageIcon(img7);
		
		String Path8 = "./img/스팸마요.jpg";
		Image img8 = new ImageIcon(Path8).getImage();
		img8 = img8.getScaledInstance(150, 100, Image.SCALE_DEFAULT);
		ImageIcon icon8 = new ImageIcon(img8);
		
		String Path9 = "./img/햄버거.jfif";
		Image img9 = new ImageIcon(Path9).getImage();
		img9 = img9.getScaledInstance(150, 100, Image.SCALE_DEFAULT);
		ImageIcon icon9 = new ImageIcon(img9);
		
		String Path10 = "./img/핫도그.png";
		Image img10 = new ImageIcon(Path10).getImage();
		img10 = img10.getScaledInstance(150, 100, Image.SCALE_DEFAULT);
		ImageIcon icon10 = new ImageIcon(img8);
		
		String Path11 = "./img/감자튀김.jfif";
		Image img11 = new ImageIcon(Path11).getImage();
		img11 = img11.getScaledInstance(150, 100, Image.SCALE_DEFAULT);
		ImageIcon icon11 = new ImageIcon(img11);
		
		String Path12 = "./img/3분카레.jfif";
		Image img12 = new ImageIcon(Path12).getImage();
		img12 = img12.getScaledInstance(150, 100, Image.SCALE_DEFAULT);
		ImageIcon icon12 = new ImageIcon(img12);
		 
		
		lb1 = new JLabel();
		lb1.setIcon(icon);
		lb2 = new JLabel();
		lb2.setIcon(icon2);
		lb3 = new JLabel();
		lb3.setIcon(icon3);
		lb4 = new JLabel();
		lb4.setIcon(icon4);
		lb5 = new JLabel();
		lb5.setIcon(icon5);
		lb6 = new JLabel();
		lb6.setIcon(icon6);
		lb7 = new JLabel();
		lb7.setIcon(icon7);
		lb8 = new JLabel();
		lb8.setIcon(icon8);
		lb9 = new JLabel();
		lb9.setIcon(icon9);
		lb10 = new JLabel();
		lb10.setIcon(icon10);
		lb11 = new JLabel();
		lb11.setIcon(icon11);
		lb12 = new JLabel();
		lb12.setIcon(icon12);
		
		 meal_bt1 = new JButton("담기"); 
	      meal_bt2 = new JButton("담기");
	      meal_bt3 = new JButton("담기");
	      meal_bt4 = new JButton("담기");
	      meal_bt5 = new JButton("담기");
	      meal_bt6 = new JButton("담기");
	      meal_bt7 = new JButton("담기");
	      meal_bt8 = new JButton("담기");
	      meal_bt9 = new JButton("담기");
	      meal_bt10 = new JButton("담기");
	      meal_bt11 = new JButton("담기");
	      meal_bt12 = new JButton("담기");
	      
	      //요거 바꿈
	      JLabel meal_lb1 = new JLabel("안성탕면",JLabel.CENTER);
	      JLabel meal_lb2 = new JLabel("신라면",JLabel.CENTER);
	      JLabel meal_lb3 = new JLabel("진라면",JLabel.CENTER);
	      JLabel meal_lb4 = new JLabel("짜파게티",JLabel.CENTER);
	      JLabel meal_lb5 = new JLabel("스파게티",JLabel.CENTER);
	      JLabel meal_lb6 = new JLabel("너구리",JLabel.CENTER);
	      JLabel meal_lb7 = new JLabel("치킨마요",JLabel.CENTER);
	      JLabel meal_lb8 = new JLabel("스팸마요",JLabel.CENTER);
	      JLabel meal_lb9 = new JLabel("햄버거",JLabel.CENTER);
	      JLabel meal_lb10 = new JLabel("핫도그",JLabel.CENTER);
	      JLabel meal_lb11 = new JLabel("감자튀김",JLabel.CENTER);
	      JLabel meal_lb12 = new JLabel("3분카레",JLabel.CENTER);
	      
	      //요거 추가 12번까지
	      meal_bt1.addActionListener(new ActionListener() {
	         
	         @Override
	         public void actionPerformed(ActionEvent e) {
	            total_price = controller.MenuList.SelectMenuList(ta_cart, meal_lb1.getText(), total_price);
	            lb_totalprice1.setText(Integer.toString(total_price));
	            MenuList.Countmenu(meal_lb1.getText());
	         }
	      });
	      meal_bt2.addActionListener(new ActionListener() {
	         
	         @Override
	         public void actionPerformed(ActionEvent e) {
	            total_price = controller.MenuList.SelectMenuList(ta_cart, meal_lb2.getText(), total_price);
	            lb_totalprice1.setText(Integer.toString(total_price));
	            MenuList.Countmenu(meal_lb2.getText());
	         }
	      });
	      meal_bt3.addActionListener(new ActionListener() {
	         
	         @Override
	         public void actionPerformed(ActionEvent e) {
	            total_price = controller.MenuList.SelectMenuList(ta_cart, meal_lb3.getText(), total_price);
	            lb_totalprice1.setText(Integer.toString(total_price));
	            MenuList.Countmenu(meal_lb3.getText());
	         }
	      });
	      meal_bt4.addActionListener(new ActionListener() {
	         
	         @Override
	         public void actionPerformed(ActionEvent e) {
	            total_price = controller.MenuList.SelectMenuList(ta_cart, meal_lb4.getText(), total_price);
	            lb_totalprice1.setText(Integer.toString(total_price));
	            MenuList.Countmenu(meal_lb4.getText());
	         }
	         
	      });
	      
	      meal_bt5.addActionListener(new ActionListener() {
	         
	         @Override
	         public void actionPerformed(ActionEvent e) {
	            total_price = controller.MenuList.SelectMenuList(ta_cart, meal_lb5.getText(), total_price);
	            lb_totalprice1.setText(Integer.toString(total_price));
	            MenuList.Countmenu(meal_lb5.getText());
	         }
	      });
	      
	      meal_bt6.addActionListener(new ActionListener() {
	         
	         @Override
	         public void actionPerformed(ActionEvent e) {
	            total_price = controller.MenuList.SelectMenuList(ta_cart, meal_lb6.getText(), total_price);
	            lb_totalprice1.setText(Integer.toString(total_price));
	            MenuList.Countmenu(meal_lb6.getText());
	         }
	      });
	      meal_bt7.addActionListener(new ActionListener() {
	         
	         @Override
	         public void actionPerformed(ActionEvent e) {
	            total_price = controller.MenuList.SelectMenuList(ta_cart, meal_lb7.getText(), total_price);
	            lb_totalprice1.setText(Integer.toString(total_price));
	            MenuList.Countmenu(meal_lb7.getText());
	         }
	      });
	      meal_bt8.addActionListener(new ActionListener() {
	         
	         @Override
	         public void actionPerformed(ActionEvent e) {
	            total_price = controller.MenuList.SelectMenuList(ta_cart, meal_lb8.getText(), total_price);
	            lb_totalprice1.setText(Integer.toString(total_price));
	            MenuList.Countmenu(meal_lb8.getText());
	         }
	      });
	      
	      meal_bt9.addActionListener(new ActionListener() {
	         
	         @Override
	         public void actionPerformed(ActionEvent e) {
	            total_price = controller.MenuList.SelectMenuList(ta_cart, meal_lb9.getText(), total_price);
	            lb_totalprice1.setText(Integer.toString(total_price));
	            MenuList.Countmenu(meal_lb9.getText());
	         }
	      });
	      meal_bt10.addActionListener(new ActionListener() {
	      
	         @Override
	         public void actionPerformed(ActionEvent e) {
	            total_price = controller.MenuList.SelectMenuList(ta_cart, meal_lb10.getText(), total_price);
	            lb_totalprice1.setText(Integer.toString(total_price));
	            MenuList.Countmenu(meal_lb10.getText());
	            
	         }
	      });
	      meal_bt11.addActionListener(new ActionListener() {
	         
	         @Override
	         public void actionPerformed(ActionEvent e) {
	            total_price = controller.MenuList.SelectMenuList(ta_cart, meal_lb11.getText(), total_price);
	            lb_totalprice1.setText(Integer.toString(total_price));
	            MenuList.Countmenu(meal_lb11.getText());
	         }
	      });
	      meal_bt12.addActionListener(new ActionListener() {
	         
	         @Override
	         public void actionPerformed(ActionEvent e) {
	            total_price = controller.MenuList.SelectMenuList(ta_cart, meal_lb12.getText(), total_price);
	            lb_totalprice1.setText(Integer.toString(total_price)); 
	            MenuList.Countmenu(meal_lb12.getText());
	         }
	      });
	      //JTextArea textArea = new JTextArea();
	      //textArea.setBounds(x, y, width, height);
	      //---------------------------1 째줄--------------------------------------
	      panel.add(lb1, 
	            new GridBagConstraints(0, 0, 1, 1,
	                  0.0, 0.0,
	                  GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
	                  new Insets(5, 5, 5, 5),
	                  20, 0));
	      panel.add(lb2, 
	            new GridBagConstraints(1, 0, 1, 1,
	                  0.0, 0.0,
	                  GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
	                  new Insets(5, 5, 5, 5),
	                  20, 0));
	      panel.add(lb3, 
	            new GridBagConstraints(2, 0, 1, 1,
	                  0.0, 0.0,
	                  GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
	                  new Insets(5, 5, 5, 5),
	                  20, 0));
	      panel.add(lb4, 
	            new GridBagConstraints(3, 0, 1, 1,
	                  0.0, 0.0,
	                  GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
	                  new Insets(5, 5, 5, 5),
	                  0, 0));
	      
	      panel.add(meal_lb1, 
	            new GridBagConstraints(0, 1, 1, 1,
	                  0.0, 0.0,
	                  GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
	                  new Insets(5, 5, 5, 25),
	                  20, 0));
	      panel.add(meal_lb2, 
	            new GridBagConstraints(1, 1, 1, 1,
	                  0.0, 0.0,
	                  GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
	                  new Insets(5, 5, 5, 25),
	                  20, 0));
	      panel.add(meal_lb3, 
	            new GridBagConstraints(2, 1, 1, 1,
	                  0.0, 0.0,
	                  GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
	                  new Insets(5, 5, 5, 25),
	                  20, 0));
	      panel.add(meal_lb4, 
	            new GridBagConstraints(3, 1, 1, 1,
	                  0.0, 0.0,
	                  GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
	                  new Insets(5, 5, 5, 5),
	                  20, 0));
	      
	      panel.add(meal_bt1, 
	            new GridBagConstraints(0, 2, 1, 1,
	                  0.0, 0.0,
	                  GridBagConstraints.CENTER, GridBagConstraints.BOTH,
	                  new Insets(5, 5, 5, 25),
	                  0, 0));
	      panel.add(meal_bt2, 
	            new GridBagConstraints(1, 2, 1, 1,
	                  0.0, 0.0,
	                  GridBagConstraints.CENTER, GridBagConstraints.BOTH,
	                  new Insets(5, 5, 5, 25),
	                  0, 0));
	      panel.add(meal_bt3, 
	            new GridBagConstraints(2, 2, 1, 1,
	                  0.0, 0.0,
	                  GridBagConstraints.CENTER, GridBagConstraints.BOTH,
	                  new Insets(5, 5, 5, 25),
	                  0, 0));
	      panel.add(meal_bt4, 
	            new GridBagConstraints(3, 2, 1, 1,
	                  0.0, 0.0,
	                  GridBagConstraints.CENTER, GridBagConstraints.BOTH,
	                  new Insets(5, 5, 5, 5),
	                  0, 0));
	      
	      
	      //----------------------------2째줄--------------------------------------
	      panel.add(lb5, 
	            new GridBagConstraints(0, 3, 1, 1,
	                  0.0, 0.0,
	                  GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
	                  new Insets(5, 5, 5, 5),
	                  0, 0));
	      panel.add(lb6, 
	            new GridBagConstraints(1, 3, 1, 1,
	                  0.0, 0.0,
	                  GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
	                  new Insets(5, 5, 5, 5),
	                  0, 0));
	      panel.add(lb7, 
	            new GridBagConstraints(2, 3, 1, 1,
	                  0.0, 0.0,
	                  GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
	                  new Insets(5, 5, 5, 5),
	                  0, 0));
	      panel.add(lb8, 
	            new GridBagConstraints(3, 3, 1, 1,
	                  0.0, 0.0,
	                  GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
	                  new Insets(5, 5, 5, 5),
	                  0, 0));
	      
	      panel.add(meal_lb5, 
	            new GridBagConstraints(0, 4, 1, 1,
	                  0.0, 0.0,
	                  GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
	                  new Insets(5, 5, 5, 25),
	                  20, 0));
	      panel.add(meal_lb6, 
	            new GridBagConstraints(1, 4, 1, 1,
	                  0.0, 0.0,
	                  GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
	                  new Insets(5, 5, 5, 25),
	                  20, 0));
	      panel.add(meal_lb7, 
	            new GridBagConstraints(2, 4, 1, 1,
	                  0.0, 0.0,
	                  GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
	                  new Insets(5, 5, 5, 25),
	                  20, 0));
	      panel.add(meal_lb8, 
	            new GridBagConstraints(3, 4, 1, 1,
	                  0.0, 0.0,
	                  GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
	                  new Insets(5, 5, 5, 5),
	                  20, 0));
	      
	      panel.add(meal_bt5, 
	            new GridBagConstraints(0, 5, 1, 1,
	                  0.0, 0.0,
	                  GridBagConstraints.CENTER, GridBagConstraints.BOTH,
	                  new Insets(5, 5, 5, 25),
	                  0, 0));
	      panel.add(meal_bt6, 
	            new GridBagConstraints(1, 5, 1, 1,
	                  0.0, 0.0,
	                  GridBagConstraints.CENTER, GridBagConstraints.BOTH,
	                  new Insets(5, 5, 5, 25),
	                  0, 0));
	      panel.add(meal_bt7, 
	            new GridBagConstraints(2, 5, 1, 1,
	                  0.0, 0.0,
	                  GridBagConstraints.CENTER, GridBagConstraints.BOTH,
	                  new Insets(5, 5, 5, 25),
	                  0, 0));
	      panel.add(meal_bt8, 
	            new GridBagConstraints(3, 5, 1, 1,
	                  0.0, 0.0,
	                  GridBagConstraints.CENTER, GridBagConstraints.BOTH,
	                  new Insets(5, 5, 5, 5),
	                  0, 0));
	      
	      
	      //----------------------------3째줄--------------------------------------
	      panel.add(lb9, 
	            new GridBagConstraints(0, 6, 1, 1,
	                  0.0, 0.0,
	                  GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
	                  new Insets(5, 5, 5, 5),
	                  0, 0));
	      panel.add(lb10, 
	            new GridBagConstraints(1, 6, 1, 1,
	                  0.0, 0.0,
	                  GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
	                  new Insets(5, 5, 5, 5),
	                  0, 0));
	      panel.add(lb11, 
	            new GridBagConstraints(2, 6, 1, 1,
	                  0.0, 0.0,
	                  GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
	                  new Insets(5, 5, 5, 5),
	                  0, 0));
	      panel.add(lb12, 
	            new GridBagConstraints(3, 6, 1, 1,
	                  0.0, 0.0,
	                  GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
	                  new Insets(5, 5, 5, 5),
	                  0, 0));
	      
	      panel.add(meal_lb9, 
	            new GridBagConstraints(0, 7, 1, 1,
	                  0.0, 0.0,
	                  GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
	                  new Insets(5, 5, 5, 25),
	                  20, 0));
	      panel.add(meal_lb10, 
	            new GridBagConstraints(1, 7, 1, 1,
	                  0.0, 0.0,
	                  GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
	                  new Insets(5, 5, 5, 25),
	                  20, 0));
	      panel.add(meal_lb11, 
	            new GridBagConstraints(2, 7, 1, 1,
	                  0.0, 0.0,
	                  GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
	                  new Insets(5, 5, 5, 25),
	                  20, 0));
	      panel.add(meal_lb12, 
	            new GridBagConstraints(3, 7, 1, 1,
	                  0.0, 0.0,
	                  GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
	                  new Insets(5, 5, 5, 5),
	                  20, 0));
	      
	      
	      panel.add(meal_bt9, 
	            new GridBagConstraints(0, 8, 1, 1,
	                  0.0, 0.0,
	                  GridBagConstraints.CENTER, GridBagConstraints.BOTH,
	                  new Insets(5, 5, 5, 25),
	                  0, 0));
	      panel.add(meal_bt10, 
	            new GridBagConstraints(1, 8, 1, 1,
	                  0.0, 0.0,
	                  GridBagConstraints.CENTER, GridBagConstraints.BOTH,
	                  new Insets(5, 5, 5, 25),
	                  0, 0));
	      panel.add(meal_bt11, 
	            new GridBagConstraints(2, 8, 1, 1,
	                  0.0, 0.0,
	                  GridBagConstraints.CENTER, GridBagConstraints.BOTH,
	                  new Insets(5, 5, 5, 25),
	                  0, 0));
	      panel.add(meal_bt12, 
	            new GridBagConstraints(3, 8, 1, 1,
	                  0.0, 0.0,
	                  GridBagConstraints.CENTER, GridBagConstraints.BOTH,
	                  new Insets(5, 5, 5, 5),
	                  0, 0));
	      
	   }
	   
	   public void drink(JPanel panel) {
		   String Path = "./img/콜라.jfif";
			Image img = new ImageIcon(Path).getImage();
			img = img.getScaledInstance(150, 100, Image.SCALE_DEFAULT);
			ImageIcon icon = new ImageIcon(img);
	      
	      String Path2 = "./img/사이다.png";
			Image img2 = new ImageIcon(Path2).getImage();
			img2 = img2.getScaledInstance(150, 100, Image.SCALE_DEFAULT);
			ImageIcon icon2 = new ImageIcon(img2);
			
			String Path3 = "./img/아메리카노.jpg";
			Image img3 = new ImageIcon(Path3).getImage();
			img3 = img3.getScaledInstance(150, 100, Image.SCALE_DEFAULT);
			ImageIcon icon3 = new ImageIcon(img3);
			
			String Path4 = "./img/환타.png";
			Image img4 = new ImageIcon(Path4).getImage();
			img4 = img4.getScaledInstance(150, 100, Image.SCALE_DEFAULT);
			ImageIcon icon4 = new ImageIcon(img4);
			
			String Path5 = "./img/라떼.jpg";
			Image img5 = new ImageIcon(Path5).getImage();
			img5 = img5.getScaledInstance(150, 100, Image.SCALE_DEFAULT);
			ImageIcon icon5 = new ImageIcon(img5);
	       
	      
	      lb1 = new JLabel();
	      lb1.setIcon(icon);
	      lb2 = new JLabel();
	      lb2.setIcon(icon2);
	      lb3 = new JLabel();
	      lb3.setIcon(icon3);
	      lb4 = new JLabel();
	      lb4.setIcon(icon4);
	      lb5 = new JLabel();
	      lb5.setIcon(icon5);
	      
	      
	      drink_bt1 = new JButton("담기");
	      drink_bt2 = new JButton("담기");
	      drink_bt3 = new JButton("담기");
	      drink_bt4 = new JButton("담기");
	      drink_bt5 = new JButton("담기");
	      
	      JLabel drink_lb1 = new JLabel("콜라",JLabel.CENTER);
	      JLabel drink_lb2 = new JLabel("사이다",JLabel.CENTER);
	      JLabel drink_lb3 = new JLabel("아메리카노",JLabel.CENTER);
	      JLabel drink_lb4 = new JLabel("환타",JLabel.CENTER);
	      JLabel drink_lb5 = new JLabel("라떼",JLabel.CENTER);
	      
	      //JTextArea textArea = new JTextArea();
	      //textArea.setBounds(x, y, width, height);
	      //---------------------------1 째줄--------------------------------------
	      panel.add(lb1, 
	            new GridBagConstraints(0, 0, 1, 1,
	                  0.0, 0.0,
	                  GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
	                  new Insets(5, 5, 5, 5),
	                  20, 0));
	      panel.add(lb2, 
	            new GridBagConstraints(1, 0, 1, 1,
	                  0.0, 0.0,
	                  GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
	                  new Insets(5, 5, 5, 5),
	                  20, 0));
	      panel.add(lb3, 
	            new GridBagConstraints(2, 0, 1, 1,
	                  0.0, 0.0,
	                  GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
	                  new Insets(5, 5, 5, 5),
	                  20, 0));
	      panel.add(lb4, 
	            new GridBagConstraints(3, 0, 1, 1,
	                  0.0, 0.0,
	                  GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
	                  new Insets(5, 5, 5, 5),
	                  0, 0));
	      panel.add(lb5, 
	            new GridBagConstraints(0, 3, 1, 1,
	                  0.0, 0.0,
	                  GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
	                  new Insets(5, 5, 5, 5),
	                  0, 0));
	      
	      panel.add(drink_lb1, 
	            new GridBagConstraints(0, 1, 1, 1,
	                  0.0, 0.0,
	                  GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
	                  new Insets(5, 5, 5, 25),
	                  20, 0));
	      panel.add(drink_lb2, 
	            new GridBagConstraints(1, 1, 1, 1,
	                  0.0, 0.0,
	                  GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
	                  new Insets(5, 5, 5, 25),
	                  20, 0));
	      panel.add(drink_lb3, 
	            new GridBagConstraints(2, 1, 1, 1,
	                  0.0, 0.0,
	                  GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
	                  new Insets(5, 5, 5, 25),
	                  20, 0));
	      panel.add(drink_lb4, 
	            new GridBagConstraints(3, 1, 1, 1,
	                  0.0, 0.0,
	                  GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
	                  new Insets(5, 5, 5, 5),
	                  20, 0));
	      panel.add(drink_lb5, 
	            new GridBagConstraints(0, 4, 1, 1,
	                  0.0, 0.0,
	                  GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
	                  new Insets(5, 5, 5, 5),
	                  20, 0));
	      
	      panel.add(drink_bt1, 
	            new GridBagConstraints(0, 2, 1, 1,
	                  0.0, 0.0,
	                  GridBagConstraints.CENTER, GridBagConstraints.BOTH,
	                  new Insets(5, 5, 5, 25),
	                  0, 0));
	      drink_bt1.addActionListener(new ActionListener() {
	         
	         @Override
	         public void actionPerformed(ActionEvent e) {
	            total_price = controller.MenuList.SelectMenuList(ta_cart, drink_lb1.getText(), total_price);
	            lb_totalprice1.setText(Integer.toString(total_price)); 
	            MenuList.Countmenu(drink_lb1.getText());
	            
	         }
	      });
	      panel.add(drink_bt2, 
	            new GridBagConstraints(1, 2, 1, 1,
	                  0.0, 0.0,
	                  GridBagConstraints.CENTER, GridBagConstraints.BOTH,
	                  new Insets(5, 5, 5, 25),
	                  0, 0));
	      drink_bt2.addActionListener(new ActionListener() {
	               
	               @Override
	               public void actionPerformed(ActionEvent e) {
	                  total_price = controller.MenuList.SelectMenuList(ta_cart, drink_lb2.getText(), total_price);
	                  lb_totalprice1.setText(Integer.toString(total_price)); 
	                  MenuList.Countmenu(drink_lb2.getText());
	               }
	      });
	      panel.add(drink_bt3, 
	            new GridBagConstraints(2, 2, 1, 1,
	                  0.0, 0.0,
	                  GridBagConstraints.CENTER, GridBagConstraints.BOTH,
	                  new Insets(5, 5, 5, 25),
	                  0, 0));
	      drink_bt3.addActionListener(new ActionListener() {
	         
	         @Override
	         public void actionPerformed(ActionEvent e) {
	            total_price = controller.MenuList.SelectMenuList(ta_cart, drink_lb3.getText(), total_price);
	            lb_totalprice1.setText(Integer.toString(total_price)); 
	            MenuList.Countmenu(drink_lb3.getText());
	            
	         }
	      });
	      panel.add(drink_bt4, 
	            new GridBagConstraints(3, 2, 1, 1,
	                  0.0, 0.0,
	                  GridBagConstraints.CENTER, GridBagConstraints.BOTH,
	                  new Insets(5, 5, 5, 5),
	                  0, 0));
	      drink_bt4.addActionListener(new ActionListener() {
	         
	         @Override
	         public void actionPerformed(ActionEvent e) {
	            total_price = controller.MenuList.SelectMenuList(ta_cart, drink_lb4.getText(), total_price);
	            lb_totalprice1.setText(Integer.toString(total_price)); 
	            MenuList.Countmenu(drink_lb4.getText());
	         }
	      });
	      
	      
	      //----------------------------2째줄--------------------------------------
	      
	        
	      
	      panel.add(drink_bt5, 
	            new GridBagConstraints(0, 5, 1, 1,
	                  0.0, 0.0,
	                  GridBagConstraints.CENTER, GridBagConstraints.BOTH,
	                  new Insets(5, 5, 5, 25),
	                  0, 0));
	      drink_bt5.addActionListener(new ActionListener() {
	         
	         @Override
	         public void actionPerformed(ActionEvent e) {
	            total_price = controller.MenuList.SelectMenuList(ta_cart, drink_lb5.getText(), total_price);
	            lb_totalprice1.setText(Integer.toString(total_price)); 
	            MenuList.Countmenu(drink_lb5.getText());
	         }
	      });

	      
	   }
	   
	   public void snack(JPanel panel) {
		   String Path = "./img/자갈치.jfif";
			Image img = new ImageIcon(Path).getImage();
			img = img.getScaledInstance(150, 100, Image.SCALE_DEFAULT);
			ImageIcon icon = new ImageIcon(img);
			
			String Path2 = "./img/오징어집.jpg";
			Image img2 = new ImageIcon(Path2).getImage();
			img2 = img2.getScaledInstance(150, 100, Image.SCALE_DEFAULT);
			ImageIcon icon2 = new ImageIcon(img2);
			
			String Path3 = "./img/꼬북칩.jpg";
			Image img3 = new ImageIcon(Path3).getImage();
			img3 = img3.getScaledInstance(150, 100, Image.SCALE_DEFAULT);
			ImageIcon icon3 = new ImageIcon(img3);
	       
	      
	      lb1 = new JLabel();
	      lb1.setIcon(icon);
	      lb2 = new JLabel();
	      lb2.setIcon(icon2);
	      lb3 = new JLabel();
	      lb3.setIcon(icon3);
	      
	      
	      snack_bt1 = new JButton("담기"); 
	      snack_bt2 = new JButton("담기");
	      snack_bt3 = new JButton("담기");
	      
	      
	      JLabel snack_lb1 = new JLabel("자갈칩",JLabel.CENTER);
	      JLabel snack_lb2 = new JLabel("오징어칩",JLabel.CENTER);
	      JLabel snack_lb3 = new JLabel("꼬북칩",JLabel.CENTER);
	      
	      
	      //JTextArea textArea = new JTextArea();
	      //textArea.setBounds(x, y, width, height);
	      //---------------------------1 째줄--------------------------------------
	      panel.add(lb1, 
	            new GridBagConstraints(0, 0, 1, 1,
	                  0.0, 0.0,
	                  GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
	                  new Insets(5, 5, 5, 5),
	                  20, 0));
	      panel.add(lb2, 
	            new GridBagConstraints(1, 0, 1, 1,
	                  0.0, 0.0,
	                  GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
	                  new Insets(5, 5, 5, 5),
	                  20, 0));
	      panel.add(lb3, 
	            new GridBagConstraints(2, 0, 1, 1,
	                  0.0, 0.0,
	                  GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
	                  new Insets(5, 5, 5, 5),
	                  20, 0));
	      
	      panel.add(snack_lb1, 
	            new GridBagConstraints(0, 1, 1, 1,
	                  0.0, 0.0,
	                  GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
	                  new Insets(5, 5, 5, 25),
	                  20, 0));
	      panel.add(snack_lb2, 
	            new GridBagConstraints(1, 1, 1, 1,
	                  0.0, 0.0,
	                  GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
	                  new Insets(5, 5, 5, 25),
	                  20, 0));
	      panel.add(snack_lb3, 
	            new GridBagConstraints(2, 1, 1, 1,
	                  0.0, 0.0,
	                  GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
	                  new Insets(5, 5, 5, 25),
	                  20, 0));
	   
	      
	      panel.add(snack_bt1, 
	            new GridBagConstraints(0, 2, 1, 1,
	                  0.0, 0.0,
	                  GridBagConstraints.CENTER, GridBagConstraints.BOTH,
	                  new Insets(5, 5, 5, 25),
	                  0, 0));
	      snack_bt1.addActionListener(new ActionListener() {
	         
	         @Override
	         public void actionPerformed(ActionEvent e) {
	            total_price = controller.MenuList.SelectMenuList(ta_cart, snack_lb1.getText(), total_price);
	            lb_totalprice1.setText(Integer.toString(total_price)); 
	            MenuList.Countmenu(snack_lb1.getText());
	         }
	      });
	      panel.add(snack_bt2, 
	            new GridBagConstraints(1, 2, 1, 1,
	                  0.0, 0.0,
	                  GridBagConstraints.CENTER, GridBagConstraints.BOTH,
	                  new Insets(5, 5, 5, 25),
	                  0, 0));
	      snack_bt2.addActionListener(new ActionListener() {
	         
	         @Override
	         public void actionPerformed(ActionEvent e) {
	            total_price = controller.MenuList.SelectMenuList(ta_cart, snack_lb2.getText(), total_price);
	            lb_totalprice1.setText(Integer.toString(total_price)); 
	            MenuList.Countmenu(snack_lb2.getText());
	         }
	      });
	      panel.add(snack_bt3, 
	            new GridBagConstraints(2, 2, 1, 1,
	                  0.0, 0.0,
	                  GridBagConstraints.CENTER, GridBagConstraints.BOTH,
	                  new Insets(5, 5, 5, 25),
	                  0, 0));
	      snack_bt3.addActionListener(new ActionListener() {
	         
	         @Override
	         public void actionPerformed(ActionEvent e) {
	            total_price = controller.MenuList.SelectMenuList(ta_cart, snack_lb3.getText(), total_price);
	            lb_totalprice1.setText(Integer.toString(total_price)); 
	            MenuList.Countmenu(snack_lb3.getText());
	         }
	      });
	      
	      
	      
	      
	      
	   }
	}