package View;

import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import controller.Connchat;
import controller.Timecontrol;
import controller.ConnUsertable;
import controller.Conngetname;

import java.util.Timer;
import java.util.TimerTask;

public class ManagerMainPage extends JFrame{
	public static Timer timer;
	public static JLabel lb_remaintimehour;
	public static JLabel lb_remaintimemin;
	public static JLabel lb_remaintimesec;
	public ManagerMainPage(String user_id , Login_GUI login_frame)
	{
		timer = new Timer();
		JFrame frame = new JFrame();
		frame.setTitle("질수없죠PC manager");
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // x 버튼 클릭시 Frame 닫기
		frame.setBounds(700,300,500,500);    // 생성 위치(x,y) 창 넓이( x,y)
		frame.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0,30,500,100);
		panel.setLayout(null);
		
		JPanel panel2 = new JPanel();
		panel2.setBounds(0,160,500,350);
		panel2.setLayout(null);
		
		JLabel lb_memberinfo = new JLabel("              - 관리자 정보 -      ");
		lb_memberinfo.setBounds(20,0,200,30);
		lb_memberinfo.setFont(new Font("Vernada", Font.BOLD, 15));
		panel.add(lb_memberinfo);
		
		JLabel lb_id = new JLabel("관리자 ID :");
		lb_id.setBounds(20,40,100,30);
		lb_id.setFont(new Font("Vernada", Font.BOLD, 15));
		panel.add(lb_id);
		
		JLabel lb_idview = new JLabel(user_id);
		lb_idview.setBounds(110,40,100,30);
		lb_idview.setFont(new Font("Vernada", Font.BOLD, 15));
		panel.add(lb_idview);
		
		JLabel lb_name = new JLabel("  이름   :");
		lb_name.setBounds(20,70,100,30);
		lb_name.setFont(new Font("Vernada", Font.BOLD, 15));
		panel.add(lb_name);
		
		Conngetname.connect();
		
		JLabel lb_nameview = new JLabel(Conngetname.Usergetname(user_id));
		lb_nameview.setBounds(110,70,100,30);
		lb_nameview.setFont(new Font("Vernada", Font.BOLD, 15));
		panel.add(lb_nameview);
		
		JLabel lb_remaintimeshow = new JLabel("  - 잔여 시간 - ");
		lb_remaintimeshow.setLayout(new FlowLayout());
		lb_remaintimeshow.setBounds(300,0,300,30);
		lb_remaintimeshow.setFont(new Font("Vernada", Font.BOLD, 15));
		panel.add(lb_remaintimeshow);
		
		JLabel lb_remaintime = new JLabel("  남은시간 : ");
		lb_remaintime.setLayout(new FlowLayout());
		lb_remaintime.setBounds(210,40,100,30);
		lb_remaintime.setFont(new Font("Vernada", Font.BOLD, 15));
		panel.add(lb_remaintime);
		
		lb_remaintimehour = new JLabel("h");
		lb_remaintimehour.setLayout(new FlowLayout());
		lb_remaintimehour.setBounds(310,40,30,30);
		lb_remaintimehour.setFont(new Font("Vernada", Font.BOLD, 15));
		panel.add(lb_remaintimehour);
		
		
		JLabel lb_remaintimehour2 = new JLabel("시");
		lb_remaintimehour2.setLayout(new FlowLayout());
		lb_remaintimehour2.setBounds(340,40,30,30);
		lb_remaintimehour2.setFont(new Font("Vernada", Font.BOLD, 15));
		panel.add(lb_remaintimehour2);
		
		lb_remaintimemin = new JLabel("m");
		lb_remaintimemin.setLayout(new FlowLayout());
		lb_remaintimemin.setBounds(370,40,30,30);
		lb_remaintimemin.setFont(new Font("Vernada", Font.BOLD, 15));
		panel.add(lb_remaintimemin);
		
		
		JLabel lb_remaintimemin2 = new JLabel("분");
		lb_remaintimemin2.setLayout(new FlowLayout());
		lb_remaintimemin2.setBounds(400,40,30,30);
		lb_remaintimemin2.setFont(new Font("Vernada", Font.BOLD, 15));
		panel.add(lb_remaintimemin2);
		
		lb_remaintimesec = new JLabel("s");
		lb_remaintimesec.setLayout(new FlowLayout());
		lb_remaintimesec.setBounds(430,40,30,30);
		lb_remaintimesec.setFont(new Font("Vernada", Font.BOLD, 15));
		panel.add(lb_remaintimesec);
		
		
		JLabel lb_remaintimesec2 = new JLabel("초");
		lb_remaintimesec2.setLayout(new FlowLayout());
		lb_remaintimesec2.setBounds(460,40,30,30);
		lb_remaintimesec2.setFont(new Font("Vernada", Font.BOLD, 15));
		panel.add(lb_remaintimesec2);
	   
	    
		Timecontrol.connect();
	      timer.scheduleAtFixedRate(new TimerTask() {
	    	  int h = 0;
	    	  int m = 0;
	    	  int s = 1;
	    	  int flag = 0;
	    	  
	         public void run() {
	        	 
	        	 
	        	 
	        	 int[] i = new int[3];
	        	 
	        	 if(flag == 0) {
	        		 i = Timecontrol.getTime(user_id);
	        		 h = i[0];
		        	 m = i[1];
	        		 flag = 1;
	        		 
	        		 }
	        	 
	        	 
	            if (s < 0) {
	               m = m - 1;
	               
	               s = 59;
	            }
	            if (m < 0) {
	               h = h - 1;
	               m = 59;
	            }
	            
	            
	            lb_remaintimehour.setText(Integer.toString(h));
	            lb_remaintimemin.setText(Integer.toString(m));
	            lb_remaintimesec.setText(Integer.toString(s));
	            
	            s --;
	            
	            if (s == -1 && h == 0 && m == 0) {
	               timer.cancel();
	               lb_remaintime.setText("시간만료");
	            } // end if
	         } // end run
	      }, 0, 1000);
		
		
		
		JButton btn_itemmanagement = new JButton("판매 상품 관리");
		btn_itemmanagement.setBounds(10,10,460,50);
		btn_itemmanagement.setFont(new Font("Vernada", Font.BOLD, 15));
		panel2.add(btn_itemmanagement);
		btn_itemmanagement.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				ItemManagement itemanagement = new ItemManagement();
			}
		});
		
		JButton btn_chat = new JButton("회원 관리");
		btn_chat.setBounds(10,70,460,50);
		btn_chat.setFont(new Font("Vernada", Font.BOLD, 15));
		panel2.add(btn_chat);
		btn_chat.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
				UserManagement usermanagement = new UserManagement();
			}
		});
		JButton btn_salesmanagement= new JButton(" 1 : 1 채팅");
		btn_salesmanagement.setBounds(10,130,460,50);
		btn_salesmanagement.setFont(new Font("Vernada", Font.BOLD, 15));
		panel2.add(btn_salesmanagement);
		btn_salesmanagement.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
				//SimpleChatServer server = new SimpleChatServer();
				Chat chat = new Chat("manager");

			}
		});
		
		JButton btn_logout = new JButton("로그아웃");
		btn_logout.setBounds(350,220,120,60);
		btn_logout.setFont(new Font("Vernada", Font.BOLD, 15));
		panel2.add(btn_logout);
		btn_logout.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				frame.dispose();
				login_frame.tf_Id.setText("");
				login_frame.pf_Pw.setText("");
				login_frame.tf_nonId.setText("");
				login_frame.setVisible(true);			
				timer.cancel();
				
				Timecontrol.updateTime(Integer.parseInt(lb_remaintimehour.getText()) , Integer.parseInt(lb_remaintimemin.getText()), lb_idview.getText());
				
			}
		});
		
		frame.add(panel);
		frame.add(panel2);
		frame.setVisible(true);
	}
}
