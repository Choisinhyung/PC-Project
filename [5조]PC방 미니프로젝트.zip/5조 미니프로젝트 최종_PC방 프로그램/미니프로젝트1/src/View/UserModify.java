package View;

import java.awt.Color;
import java.awt.Font;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import controller.ConnUsermodi;
import controller.ConnItemmodi;
import controller.ConnUsertable;

public class UserModify {
	public UserModify() {
		JFrame frame = new JFrame();
		frame.setTitle("회원정보 수정");
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // x 버튼 클릭시 Frame 닫기
		frame.setBounds(1337,300,300,500);    // 생성 위치(x,y) 창 넓이( x,y)
		frame.setLayout(null);
		
		
		
		Panel prev_modi_panel = new Panel();
		prev_modi_panel.setBounds(10,10,265,60);
		prev_modi_panel.setLayout(null);
		prev_modi_panel.setBackground(Color.white);
		
		
		Panel modi_panel = new Panel();
		modi_panel.setBounds(10,80,265,290);
		modi_panel.setLayout(null);
		modi_panel.setBackground(Color.white);
		
		Panel btn_panel = new Panel();
		btn_panel.setBounds(10,380,265,60);
		btn_panel.setLayout(null);
		btn_panel.setBackground(Color.white);
		
		//-------------------------------prev_modi_panel----------------------------
		
		
		JLabel lb_prev_modi_id  = new JLabel("변경할 사용자 ID :",JLabel.CENTER);
		lb_prev_modi_id.setBounds(0,10,120,40);
		lb_prev_modi_id.setFont(new Font("Vernada", Font.BOLD, 15));
		prev_modi_panel.add(lb_prev_modi_id);
		
		JTextField tf_prev_id = new JTextField(30);
		tf_prev_id.setBounds(130,10,120,40);
		tf_prev_id.setFont(new Font("Vernada", Font.BOLD, 15));
		prev_modi_panel.add(tf_prev_id);
		
		
		//-------------------------------modi_panel------------------------------
		
		JLabel lb_user_type   = new JLabel("분류 : ",JLabel.CENTER);
		lb_user_type.setBounds(0,10,120,40);
		lb_user_type.setFont(new Font("Vernada", Font.BOLD, 15));
		modi_panel.add(lb_user_type);
		
		JLabel lb_user_name  = new JLabel("이름 : ",JLabel.CENTER);
		lb_user_name.setBounds(0,55,120,40);
		lb_user_name.setFont(new Font("Vernada", Font.BOLD, 15));
		modi_panel.add(lb_user_name);
		
		JLabel lb_user_id  = new JLabel(" ID : ",JLabel.CENTER);
		lb_user_id.setBounds(0,100,120,40);
		lb_user_id.setFont(new Font("Vernada", Font.BOLD, 15));
		modi_panel.add(lb_user_id);
		
		JLabel lb_user_pw  = new JLabel("PW : ",JLabel.CENTER);
		lb_user_pw.setBounds(0,145,120,40);
		lb_user_pw.setFont(new Font("Vernada", Font.BOLD, 15));
		modi_panel.add(lb_user_pw);
		
	
		JTextField tf_modi_type = new JTextField(30);
		tf_modi_type.setBounds(130,10,120,40);
		tf_modi_type.setFont(new Font("Vernada", Font.BOLD, 15));
		modi_panel.add(tf_modi_type);
		
		JTextField tf_modi_name = new JTextField(30);
		tf_modi_name.setBounds(130,55,120,40);
		tf_modi_name.setFont(new Font("Vernada", Font.BOLD, 15));
		modi_panel.add(tf_modi_name);
		
		JTextField tf_modi_id = new JTextField(30);
		tf_modi_id.setBounds(130,100,120,40);
		tf_modi_id.setFont(new Font("Vernada", Font.BOLD, 15));
		modi_panel.add(tf_modi_id);
		
		JTextField tf_modi_pw = new JTextField(30);
		tf_modi_pw.setBounds(130,145,120,40);
		tf_modi_pw.setFont(new Font("Vernada", Font.BOLD, 15));
		modi_panel.add(tf_modi_pw);
		
	
		

		///-------------------button panel---------------------------
		
		JButton btn_apply = new JButton("적용");
		btn_apply.setBounds(10,10,110,40);
		btn_panel.add(btn_apply);
		btn_apply.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				ConnUsermodi.connect();
				ConnUsermodi itemmopiapply = new ConnUsermodi(tf_prev_id.getText(),tf_modi_type.getText(),tf_modi_name.getText(),tf_modi_id.getText(),tf_modi_pw.getText());
	
			}
		});
		
		JButton btn_cancel = new JButton("취소");
		btn_cancel.setBounds(140,10,110,40);
		btn_panel.add(btn_cancel);
		btn_cancel.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				frame.dispose();
			}
		});
		frame.add(prev_modi_panel);
		frame.add(modi_panel);
		frame.add(btn_panel);
		frame.setVisible(true);
	}
}
