package View;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;
import java.util.Timer;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.JTextField;

import View.CustMainPage;
import controller.SignIN;
import connectDB.CloseHelper;
public class Login_GUI extends JFrame {
	
	static public JTextField tf_Id;
	static public JTextField tf_nonId;
	static public JPasswordField pf_Pw;
	static Login_GUI frame;
	public Login_GUI() {
		setTitle("질수없죠PC manager");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // x 버튼 클릭시 Frame 닫기
		setBounds(700,300,500,500);    // 생성 위치(x,y) 창 넓이( x,y)
		setLayout(null);

	}
	public static void Login_View(Login_GUI a)
	{
		JPanel panel = new JPanel();
		panel.setBounds(100,160,300,25);
		panel.setLayout(null);

		JPanel panel2 = new JPanel();
		panel2.setBounds(100,190,300,70);
		panel2.setLayout(null);
		
		JPanel panel2_1 = new JPanel();
		panel2_1.setBounds(100,190,300,70);
		panel2_1.setLayout(null);
		
		JPanel panel3 = new JPanel();
		panel3.setBounds(100,240,300,200);
		panel3.setLayout(null);

		//-------------------------------로그인 아이디 PW 입력부-----------------------
		JLabel lb_id = new JLabel("ID :");
		lb_id.setBounds(20,0,20,25);
		panel2.add(lb_id);
		
		tf_Id = new JTextField();
		tf_Id.setBounds(50, 0, 120, 25);
		panel2.add(tf_Id);
		tf_Id.setColumns(10);
		
		JLabel lb_pw = new JLabel("PW : ");
		lb_pw.setBounds(10,33,30,25);
		panel2.add(lb_pw);
		
		pf_Pw = new JPasswordField();
		pf_Pw.setBounds(50, 33, 120, 25);
		panel2.add(pf_Pw);
		
		//-------------------------------비회원 로그인 아이디 PW 입력부-----------------------
		JLabel lb_nonid = new JLabel("비회원 번호 :");
		lb_nonid.setBounds(0,20,100,30);
		panel2_1.add(lb_nonid);
			
		tf_nonId = new JTextField();
		tf_nonId.setBounds(80, 20, 130, 30);
		panel2_1.add(tf_nonId);
		tf_nonId.setColumns(10);
			
		//-------------------------------로그인 라디오 버튼-----------------------

		JRadioButton btn_manager = new JRadioButton("Manager",true);
		btn_manager.setBounds(0,0,100,25);
		panel.add(btn_manager);
		btn_manager.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				panel2_1.setVisible(false);
				panel2.setVisible(true);
			}
		});
		
		JRadioButton btn_member = new JRadioButton("Member",false);
		btn_member.setBounds(110,0,100,25);
		panel.add(btn_member);
		btn_member.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				panel2_1.setVisible(false);
				panel2.setVisible(true);
			}
		});
		
		JRadioButton btn_nonmember = new JRadioButton("nonMember",false);
		btn_nonmember.setBounds(210,0,100,25);
		panel.add(btn_nonmember);
		btn_nonmember.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				panel2_1.setVisible(true);
				panel2.setVisible(false);
			}
		});
		
		
		ButtonGroup bt_group = new ButtonGroup();
		bt_group.add(btn_nonmember);
		bt_group.add(btn_member);
		bt_group.add(btn_manager);
		

		
		//-------------------------------로그인 , 회원가입 버튼  -------------------------
		
		JButton btn_Login = new JButton("로그인");
		btn_Login.setBounds(180,0,120,55);
		panel2.add(btn_Login);
		btn_Login.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				if(btn_member.isSelected() == true )
				{
					if(SignIN.LoginCheck("member" ,(String)(tf_Id.getText()), (String)(pf_Pw.getText())) == true) {
						CustMainPage custmainpage = new CustMainPage(tf_Id.getText(),frame);
						
						frame.dispose();
						}
					else JOptionPane.showMessageDialog(null,"비밀번호가 일치하지 않습니다.");
				}
				else if(btn_manager.isSelected() == true)
				{ 
					if(SignIN.LoginCheck("manager" ,(String)(tf_Id.getText()), (String)(pf_Pw.getText())) == true) {
						ManagerMainPage managermainpage = new ManagerMainPage(tf_Id.getText(),frame);
						frame.dispose();
						}
					else JOptionPane.showMessageDialog(null,"비밀번호가 일치하지 않습니다.");
				}
				
			}
		});
		JButton btn_memberJoin = new JButton("회원가입");
		btn_memberJoin.setBounds(10,20,290,25);
		panel3.add(btn_memberJoin);
		
		btn_memberJoin.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub				
				Join join = new Join();				
			}
		});
		
		JButton btn_searchPw = new JButton("비밀번호 찾기");
		btn_searchPw.setBounds(10,50,290,25);
		panel3.add(btn_searchPw);
		btn_searchPw.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				PwSearch pwsearch = new PwSearch();
			}
		});
		JButton btn_nonLogin = new JButton("로그인");
		btn_nonLogin.setBounds(220,20,80,30);
		panel2_1.add(btn_nonLogin);
		btn_nonLogin.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				if(btn_nonmember.isSelected() == true )
				{
					if(SignIN.non_LoginCheck("nonmember" ,tf_nonId.getText()) == true)
					{
						CustMainPage custmainpage = new CustMainPage(tf_nonId.getText(),frame);
						frame.dispose();
					}
				else JOptionPane.showMessageDialog(null,"비밀번호가 일치하지 않습니다.");
				}
			}
		});
		
		frame.add(panel);
		frame.add(panel2);
		frame.add(panel2_1);
		
		panel2_1.setVisible(false);
		frame.add(panel3);
		
		frame.setVisible(true);
			
	}
	public static void main(String[] args) {
	SignIN.connect();
	frame = new Login_GUI();
	Login_View(frame);
	
}
	
	
}
