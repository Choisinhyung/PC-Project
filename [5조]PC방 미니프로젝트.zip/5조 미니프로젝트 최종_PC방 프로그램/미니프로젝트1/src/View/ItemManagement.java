package View;

import java.awt.Color;
import java.awt.Font;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import controller.ItemView;
public class ItemManagement extends JFrame {
	public static Object[][]data;
	public static JTable ta_cart;
	public static int viewindex = 0;
	public ItemManagement() {
		JFrame frame = new JFrame();
		frame.setTitle("판매상품 관리");
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // x 버튼 클릭시 Frame 닫기
		frame.setBounds(650,300,700,500);    // 생성 위치(x,y) 창 넓이( x,y)
		frame.setLayout(null);
		
		
		
		Panel tablepanel = new Panel();
		tablepanel.setBounds(10,30,665,250);
		tablepanel.setLayout(null);
		tablepanel.setBackground(Color.white);
		
		
		Panel btnpanel = new Panel();
		btnpanel.setBounds(10,290,665,90);
		btnpanel.setLayout(null);
		btnpanel.setBackground(Color.white);
		//리스트 초기화 및 총금액 , 판매수량 알고리즘 필요 ***********************************************
		
		data = new Object[7][150];
		String[] column = {"분류","상품명","상품가격","현재수량","판매수량","원자재 가격","상품별 매출"};
		DefaultTableModel model=new DefaultTableModel(column,0);
		ta_cart = new JTable(model);
		
		ta_cart.setBounds(10, 20, 680,300);
		ta_cart.setFont(new Font("Vernada", Font.BOLD, 15));
		
		JScrollPane tablescroll = new JScrollPane(ta_cart);
		tablescroll.setBounds(10, 20, 650,160);
		tablescroll.setBackground(Color.white);
		tablepanel.add(tablescroll);
		
		JLabel lb_totalprice = new JLabel("총 판매 금액 :",JLabel.CENTER);
		lb_totalprice.setBounds(10,200,120,40);
		lb_totalprice.setFont(new Font("Vernada", Font.BOLD, 15));
		tablepanel.add(lb_totalprice);
		JLabel lb_totalprice2 = new JLabel("0",JLabel.CENTER);
		lb_totalprice2.setBounds(140,200,80,40);
		lb_totalprice2.setFont(new Font("Vernada", Font.BOLD, 15));
		tablepanel.add(lb_totalprice2);
		JLabel lb_totalprice3 = new JLabel("원");
		lb_totalprice3.setBounds(240,200,60,40);
		lb_totalprice3.setFont(new Font("Vernada", Font.BOLD, 15));
		tablepanel.add(lb_totalprice3);
		
		JLabel lb_profit = new JLabel("순 이익 :",JLabel.CENTER);
		lb_profit.setBounds(350,200,120,40);
		lb_profit.setFont(new Font("Vernada", Font.BOLD, 15));
		tablepanel.add(lb_profit);
		JLabel lb_profit2 = new JLabel("0",JLabel.CENTER);
		lb_profit2.setBounds(490,200,80,40);
		lb_profit2.setFont(new Font("Vernada", Font.BOLD, 15));
		tablepanel.add(lb_profit2);
		JLabel lb_profit3 = new JLabel("원");
		lb_profit3.setFont(new Font("Vernada", Font.BOLD, 15));
		lb_profit3.setBounds(590,200,60,40);
		tablepanel.add(lb_profit3);
		
		
		//-------------------------------------------button-----------------------
		
		JButton btn_ItemView = new JButton("판매상품 보기");
		btn_ItemView.setBounds(0, 10, 320, 60);
		btnpanel.add(btn_ItemView);
		btn_ItemView.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				ItemView.connect();
				int[] temp = new int[3]; 
				temp = ItemView.itemview(ta_cart,viewindex);
				lb_totalprice2.setText(Integer.toString(temp[0])); 
				lb_profit2.setText(Integer.toString(temp[1])); 
				viewindex = temp[2];
				
			}
		});
		
		
		JButton btn_Itemmodify = new JButton("판매상품 수정");
		btn_Itemmodify.setBounds(340, 10, 320, 60);
		btnpanel.add(btn_Itemmodify);
		btn_Itemmodify.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				ItemModify itemmodify = new ItemModify();
			}
		});
		
		JButton btn_exit = new JButton("나가기");
		btn_exit.setBounds(510, 410, 160, 30);
		btnpanel.add(btn_exit);
		btn_exit.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				frame.dispose();
				
			}
		});
		frame.add(btn_exit);
		frame.add(btnpanel);
		frame.add(tablepanel);
		frame.setVisible(true);
		
	}
	
}
