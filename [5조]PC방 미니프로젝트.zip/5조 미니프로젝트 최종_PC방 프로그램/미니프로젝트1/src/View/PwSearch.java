package View;

import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import controller.ConnPwsearch;

public class PwSearch extends JFrame{
	static private JTextField tf_Id;
	static private JTextField tf_Pw;
	static private JTextField tf_Name;
	public PwSearch() {
		JFrame frame = new JFrame();
		
		frame.setTitle("비밀번호 찾기");
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // x 버튼 클릭시 해당 Frame 닫기
		frame.setBounds(800,400,320,300);    // 생성 위치(x,y) 창 넓이( x,y)
		frame.setLayout(null);
		
		Panel panel = new Panel();
		panel.setBounds(0,0,320,300);
		panel.setLayout(null);
		
		JLabel lb_id = new JLabel("ID :");
		lb_id.setBounds(83,70,30,30);
		panel.add(lb_id);
		
		tf_Id = new JTextField();
		tf_Id.setBounds(110, 70, 120, 30);
		panel.add(tf_Id);
		tf_Id.setColumns(10);
	
		JLabel lb_name = new JLabel("NAME :");
		lb_name.setBounds(60,110,50,30);
		panel.add(lb_name);
		
		JTextField tf_Name = new JTextField();
		tf_Name.setBounds(110, 110, 120, 30);
		panel.add(tf_Name);
		tf_Name.setColumns(10);
		
		JButton btn_Login = new JButton("Search");
		btn_Login.setBounds(70,150,160,50);
		panel.add(btn_Login);
		btn_Login.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				String[] temp = new String[2];
				temp  = ConnPwsearch.Pwsearch(tf_Id.getText(),tf_Name.getText());
				if(temp[1]== "success")
				{	
					JOptionPane.showMessageDialog(null,"PW : " + temp[0]);
					frame.setVisible(false);
				}
				else {
					JOptionPane.showMessageDialog(null,"비밀번호를 찾을 수 없습니다.");
				}
			}
		});
		
		frame.add(panel);
		frame.setVisible(true);
	}
	
	
}
