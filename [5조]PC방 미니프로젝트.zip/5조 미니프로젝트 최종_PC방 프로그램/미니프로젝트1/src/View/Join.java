package View;

import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import controller.JOIN_;
public class Join extends JFrame{
	static private JTextField tf_Id;
	static private JTextField tf_Pw;
	static private JTextField tf_Name;
	public Join() {
		JFrame frame = new JFrame();
		
		frame.setTitle("회원가입");
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // x 버튼 클릭시 해당 Frame 닫기
		frame.setBounds(800,400,320,300);    // 생성 위치(x,y) 창 넓이( x,y)
		frame.setLayout(null);
		
		Panel panel = new Panel();
		panel.setBounds(0,0,320,300);
		panel.setLayout(null);
		
		JLabel lb_id = new JLabel("ID :");
		lb_id.setBounds(83,40,30,30);
		panel.add(lb_id);
		
		tf_Id = new JTextField();
		tf_Id.setBounds(110, 40, 120, 30);
		panel.add(tf_Id);
		tf_Id.setColumns(10);
		
		JLabel lb_pw = new JLabel("PW :");
		lb_pw.setBounds(73,80,30,30);
		panel.add(lb_pw);
		
		tf_Pw = new JTextField();
		tf_Pw.setBounds(110, 80, 120, 30);
		panel.add(tf_Pw);
		tf_Pw.setColumns(10);
		
		JLabel lb_name = new JLabel("NAME :");
		lb_name.setBounds(60,120,50,30);
		panel.add(lb_name);
		
		tf_Name = new JTextField();
		tf_Name.setBounds(110, 120, 120, 30);
		panel.add(tf_Name);
		tf_Name.setColumns(10);
		
		JButton btn_Login = new JButton("회원가입 신청");
		btn_Login.setBounds(70,170,160,50);
		panel.add(btn_Login);
		btn_Login.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				frame.setVisible(false);
				JOIN_.connect();
				JOIN_.Join_request(tf_Name.getText(), tf_Id.getText(), tf_Pw.getText());
				
			}
		});
		
		frame.add(panel);
		frame.setVisible(true);
	}
	
	
}
