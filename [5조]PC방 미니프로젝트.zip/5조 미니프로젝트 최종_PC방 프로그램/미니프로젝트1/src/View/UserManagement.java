package View;

import java.awt.Color;
import java.awt.Font;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import controller.ConnUserdel;
import controller.ConnUsertable;

public class UserManagement extends JFrame {
	
	public static Object[][]data;
	public static JTable ta_userlist;
	public static JTable ta_usersearch;
	public static int viewindex = 0;
	public static int viewindex1 = 0;
	public UserManagement() {
		JFrame frame = new JFrame();
		frame.setTitle("사용자 관리");
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // x 버튼 클릭시 Frame 닫기
		frame.setBounds(650,300,700,500);    // 생성 위치(x,y) 창 넓이( x,y)
		frame.setLayout(null);
		
		
		
		Panel tablepanel = new Panel();
		tablepanel.setBounds(10,10,665,225);
		tablepanel.setLayout(null);
		tablepanel.setBackground(Color.white);
		
		
		Panel btnpanel = new Panel();
		btnpanel.setBounds(10,245,665,150);
		btnpanel.setLayout(null);
		btnpanel.setBackground(Color.white);
		//리스트 초기화 및 총금액 , 판매수량 알고리즘 필요 ***********************************************
		
		data = new Object[7][150];
		String[] usercolumn = {"분류","성명","ID","비밀번호","남은시간"};
		DefaultTableModel model=new DefaultTableModel(usercolumn,0);
		ta_userlist = new JTable(model);
		ta_userlist.setBounds(10, 20, 680,300);
		ta_userlist.setFont(new Font("Vernada", Font.BOLD, 15));
		
		String[] searchcolumn = {"분류","성명","ID","비밀번호","남은시간"};
		DefaultTableModel model2=new DefaultTableModel(searchcolumn,0);
		ta_usersearch = new JTable(model2);
		ta_usersearch.setBounds(10, 20, 680,300);
		ta_usersearch.setFont(new Font("Vernada", Font.BOLD, 15));
		
		JScrollPane tablescroll = new JScrollPane(ta_userlist);
		tablescroll.setBounds(10, 10, 650,160);
		tablescroll.setBackground(Color.white);
		tablepanel.add(tablescroll);
		
		JScrollPane tablescroll2 = new JScrollPane(ta_usersearch);
		tablescroll2.setBounds(10, 10, 650,40);
		tablescroll2.setBackground(Color.white);
		btnpanel.add(tablescroll2);
		
		JLabel lb_userid = new JLabel("사용자 ID 검색 :",JLabel.CENTER);
		lb_userid.setBounds(10,180,120,40);
		lb_userid.setFont(new Font("Vernada", Font.BOLD, 15));
		tablepanel.add(lb_userid);
		
		JTextField tf_userid_input= new JTextField();
		tf_userid_input.setBounds(140,180,120,40);
		tf_userid_input.setFont(new Font("Vernada", Font.BOLD, 15));
		tablepanel.add(tf_userid_input);
		
		
		//-------------------------------------------button-----------------------
		
		JButton btn_search = new JButton("검색");
		btn_search.setBounds(280,180,120,40);
		btn_search.setFont(new Font("Vernada", Font.BOLD, 15));
		tablepanel.add(btn_search);
		btn_search.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				viewindex1 = ConnUsertable.connusertable(ta_usersearch,(String)tf_userid_input.getText(),viewindex1);
			}
		});
		
		JButton btn_updateUI = new JButton("Table 갱신");
		btn_updateUI.setBounds(440,180,220,40);
		btn_updateUI.setFont(new Font("Vernada", Font.BOLD, 15));
		tablepanel.add(btn_updateUI);
		btn_updateUI.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				ConnUsertable.connect();
				viewindex = ConnUsertable.connusertable(ta_userlist, viewindex);
			}
		});
		
		JButton btn_usermodi = new JButton("회원정보 수정");
		btn_usermodi.setBounds(10, 70, 310, 60);
		btnpanel.add(btn_usermodi);
		btn_usermodi.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				UserModify usermodify = new UserModify();
			}
		});
		
		JButton btn_userdel = new JButton("회원정보 삭제");
		btn_userdel.setBounds(340, 70, 320, 60);
		btnpanel.add(btn_userdel);
		btn_userdel.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				ConnUserdel.connect();
				ConnUserdel userdel = new ConnUserdel(tf_userid_input.getText());
			}
		});
		
		JButton btn_exit = new JButton("나가기");
		btn_exit.setBounds(510, 410, 160, 30);
		btnpanel.add(btn_exit);
		btn_exit.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				frame.dispose();
				
			}
		});
		
		
		
		
		frame.add(btn_exit);
		frame.add(btnpanel);
		frame.add(tablepanel);
		ConnUsertable.connect();
		viewindex = ConnUsertable.connusertable(ta_userlist, viewindex);
		frame.setVisible(true);
		
		
	}
	
}
