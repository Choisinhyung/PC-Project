package View;

import java.awt.Font;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import controller.PaymentInfo;
import controller.Timecontrol;
import controller.MenuList;

public class Payment extends JFrame {
	private static String temp;
	public static Timer pay_timer;
	public static boolean flag = false;
	public Payment(JFrame chargeframe, String payment_type, String name, String time) {
		
		temp = payment_type;
		JFrame frame = new JFrame();
		frame.setTitle("결제");
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // x 버튼 클릭시 Frame 닫기
		frame.setBounds(800, 400, 320, 300); // 생성 위치(x,y) 창 넓이( x,y)
		frame.setLayout(null);

		Panel panel = new Panel();
		panel.setBounds(0, 0, 320, 300);
		panel.setLayout(null);

		JRadioButton btn_cardtypeVISA = new JRadioButton("VISA", true);
		btn_cardtypeVISA.setBounds(40, 10, 120, 30);
		panel.add(btn_cardtypeVISA);

		JRadioButton btn_cardtypeMASTER = new JRadioButton("MASTER", false);
		btn_cardtypeMASTER.setBounds(170, 10, 120, 30);
		panel.add(btn_cardtypeMASTER);

		ButtonGroup bt_group = new ButtonGroup();
		bt_group.add(btn_cardtypeVISA);
		bt_group.add(btn_cardtypeMASTER);

		JLabel lb_cardnum = new JLabel("- 카드번호 -");
		lb_cardnum.setBounds(20, 40, 100, 20);
		lb_cardnum.setFont(new Font("Vernada", Font.BOLD, 15));
		panel.add(lb_cardnum);

		JTextField tf_cardnum1 = new JTextField();
		tf_cardnum1.setBounds(20, 70, 50, 20);
		panel.add(tf_cardnum1);

		JTextField tf_cardnum2 = new JTextField();
		tf_cardnum2.setBounds(90, 70, 50, 20);
		panel.add(tf_cardnum2);

		JTextField tf_cardnum3 = new JTextField();
		tf_cardnum3.setBounds(160, 70, 50, 20);
		panel.add(tf_cardnum3);

		JTextField tf_cardnum4 = new JTextField();
		tf_cardnum4.setBounds(230, 70, 50, 20);
		panel.add(tf_cardnum4);

		JLabel lb_delimiter1 = new JLabel("-");
		lb_delimiter1.setBounds(76, 70, 5, 10);
		lb_delimiter1.setFont(new Font("Vernada", Font.BOLD, 15));
		panel.add(lb_delimiter1);

		JLabel lb_delimiter2 = new JLabel("-");
		lb_delimiter2.setBounds(146, 70, 5, 10);
		lb_delimiter2.setFont(new Font("Vernada", Font.BOLD, 15));
		panel.add(lb_delimiter2);

		JLabel lb_delimiter3 = new JLabel("-");
		lb_delimiter3.setBounds(216, 70, 5, 10);
		lb_delimiter3.setFont(new Font("Vernada", Font.BOLD, 15));
		panel.add(lb_delimiter3);

		JLabel lb_cardMMYY = new JLabel("- 년월(MMYY)-");
		lb_cardMMYY.setBounds(20, 100, 130, 20);
		lb_cardMMYY.setFont(new Font("Vernada", Font.BOLD, 15));
		panel.add(lb_cardMMYY);

		JTextField tf_cardMM = new JTextField();
		tf_cardMM.setBounds(20, 130, 50, 20);
		panel.add(tf_cardMM);

		JTextField tf_cardYY = new JTextField();
		tf_cardYY.setBounds(90, 130, 50, 20);
		panel.add(tf_cardYY);

		JLabel lb_delimiter5 = new JLabel("/");
		lb_delimiter5.setBounds(75, 130, 5, 20);
		lb_delimiter5.setFont(new Font("Vernada", Font.BOLD, 15));
		panel.add(lb_delimiter5);

		JLabel lb_cardCVC = new JLabel("- CVC -");
		lb_cardCVC.setBounds(155, 100, 100, 20);
		lb_cardCVC.setFont(new Font("Vernada", Font.BOLD, 15));
		panel.add(lb_cardCVC);

		JTextField tf_cardCVC = new JTextField();
		tf_cardCVC.setBounds(160, 130, 60, 20);
		panel.add(tf_cardCVC);

		JLabel lb_cardpw = new JLabel("- 비밀번호 -");
		lb_cardpw.setBounds(20, 156, 130, 20);
		lb_cardpw.setFont(new Font("Vernada", Font.BOLD, 15));
		panel.add(lb_cardpw);

		JTextField tf_cardpw = new JTextField();
		tf_cardpw.setBounds(20, 180, 260, 25);
		panel.add(tf_cardpw);

		JButton btn_payment = new JButton("결제");
		btn_payment.setFont(new Font("Vernada", Font.BOLD, 15));
		btn_payment.setBounds(20, 215, 180, 35);
		panel.add(btn_payment);

		JButton btn_paymentcancel = new JButton("취소");
		btn_paymentcancel.setFont(new Font("Vernada", Font.BOLD, 15));
		btn_paymentcancel.setBounds(210, 215, 70, 35);
		panel.add(btn_paymentcancel);

		btn_payment.addActionListener(new ActionListener() {

			// 정보가 들어가서 결제완료
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				if(temp == "time")
				{
						if (btn_cardtypeVISA.isSelected() == true) {
		
							PaymentInfo.connect();
		
							String cardType = btn_cardtypeVISA.getText();
		
							String cardNum1 = tf_cardnum1.getText();
							String cardNum2 = tf_cardnum2.getText();
							String cardNum3 = tf_cardnum3.getText();
							String cardNum4 = tf_cardnum4.getText();
		
							String cardNum = cardNum1 + cardNum2 + cardNum3 + cardNum4;
							
							if (PaymentInfo.TimepayCheck(cardType, cardNum, Integer.parseInt(tf_cardYY.getText()),
									Integer.parseInt(tf_cardMM.getText()), Integer.parseInt(tf_cardCVC.getText()),
									Integer.parseInt(tf_cardpw.getText())) == true) 
							{
								PaymentInfo.TimeUpdate(time,name);
								frame.dispose();
								JOptionPane.showMessageDialog(null, "결제가 완료되었습니다. ");
								CustMainPage.timer.cancel();
								if(flag == false)
								{
									pay_timer = new Timer();
									flag = true;
								}
								else 
								{
									pay_timer.cancel();
									pay_timer = new Timer();
								}
								pay_timer.scheduleAtFixedRate(new TimerTask() {
							    	  int h = 0;
							    	  int m = 0;
							    	  int s = 1;
							    	  int flag = 0;
							         public void run() {
							        	 
							        	 
							        	 
							        	 int[] i = new int[3];
							        	 Timecontrol.connect();
							        	 if(flag == 0) {
							        		 i = Timecontrol.getTime(name);
							        		 h = i[0];
								        	 m = i[1];
							        		 flag = 1;
							        		 }
							        	 
							        	 
							            if (s < 0) {
							               m = m - 1;
							               s = 59;
							            }
							            if (m < 0) {
							               h = h - 1;
							               m = 59;
							            }
							            
							            //lb_remaintime.setText("남은 시간 : " + h + "시간 " + m + "분 " + s + "초");
							            CustMainPage.lb_remaintimehour.setText(Integer.toString(h));
							            CustMainPage.lb_remaintimemin.setText(Integer.toString(m));
							            CustMainPage.lb_remaintimesec.setText(Integer.toString(s));
							            //lb_remaintime.updateUI();
							            s --;
							            //							            Timecontrol.updateTime(h, m, user_id);
							            if (s == -1 && h == 0 && m == 0) {
							               pay_timer.cancel();
							               //CustMainPage.lb_remaintime.setText("시간만료");
							            } // end if
							         } // end run
							      }, 0, 1000);
								
							}
							else {
								JOptionPane.showMessageDialog(null, "카드정보가 일치하지 않습니다. ");
							}
		
						 
						}else if (btn_cardtypeMASTER.isSelected() == true) {
	
						PaymentInfo.connect();
	
						String cardType = btn_cardtypeMASTER.getText();
						
						String cardNum1 = tf_cardnum1.getText();
						String cardNum2 = tf_cardnum2.getText();
						String cardNum3 = tf_cardnum3.getText();
						String cardNum4 = tf_cardnum4.getText();
						
						String cardNum = cardNum1 + cardNum2 + cardNum3 + cardNum4;
	
	
						if (PaymentInfo.TimepayCheck(cardType, cardNum, Integer.parseInt(tf_cardYY.getText()),
								Integer.parseInt(tf_cardMM.getText()), Integer.parseInt(tf_cardCVC.getText()),
								Integer.parseInt(tf_cardpw.getText())) == true) {
							
							PaymentInfo.TimeUpdate(time,name);
							frame.dispose();
							JOptionPane.showMessageDialog(null, "결제가 완료되었습니다. ");
							CustMainPage.timer.cancel();
							if(flag == false)
							{
								pay_timer = new Timer();
								flag = true;
							}
							else 
							{
								pay_timer.cancel();
								pay_timer = new Timer();
							}
							
							pay_timer.scheduleAtFixedRate(new TimerTask() {
						    	  int h = 0;
						    	  int m = 0;
						    	  int s = 1;
						    	  int flag = 0;
						    	  
						         public void run() {
						        	 
						        	 
						        	 
						        	 int[] i = new int[3];
						        	 Timecontrol.connect();
						        	 if(flag == 0) {
						        		 i = Timecontrol.getTime(name);
						        		 h = i[0];
							        	 m = i[1];
						        		 flag = 1;
						        		 
						        		 }
						        	 
						        	 
						            if (s < 0) {
						               m = m - 1;
						               s = 59;
						            }
						            if (m < 0) {
						               h = h - 1;
						               m = 59;
						            }
						            
						            //lb_remaintime.setText("남은 시간 : " + h + "시간 " + m + "분 " + s + "초");
						            CustMainPage.lb_remaintimehour.setText(Integer.toString(h));
						            CustMainPage.lb_remaintimemin.setText(Integer.toString(m));
						            CustMainPage.lb_remaintimesec.setText(Integer.toString(s));
						            //lb_remaintime.updateUI();
						            s --;
						            //Timecontrol.updateTime(h, m, name);
						            if (s == -1 && h == 0 && m == 0) {
						               pay_timer.cancel();
						               //CustMainPage.lb_remaintime.setText("시간만료");
						            } // end if
						         } // end run
						      }, 0, 1000);
							
						}
						else {
							JOptionPane.showMessageDialog(null, "카드정보가 일치하지 않습니다. ");
						}
	
						
						
					}
				}
				
			}
		});

		btn_paymentcancel.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				frame.dispose();
			}
		});

		frame.add(panel);
		frame.setVisible(true);
	}
	
	
	
	



	public Payment(JTable ta_cart, JLabel lb_totalprice1, String payment_type, String name, String a) {
		// TODO Auto-generated constructor stub
		temp = payment_type;
		JFrame frame = new JFrame();
		frame.setTitle("결제");
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // x 버튼 클릭시 Frame 닫기
		frame.setBounds(800, 400, 320, 300); // 생성 위치(x,y) 창 넓이( x,y)
		frame.setLayout(null);

		Panel panel = new Panel();
		panel.setBounds(0, 0, 320, 300);
		panel.setLayout(null);

		JRadioButton btn_cardtypeVISA = new JRadioButton("VISA", true);
		btn_cardtypeVISA.setBounds(40, 10, 120, 30);
		panel.add(btn_cardtypeVISA);

		JRadioButton btn_cardtypeMASTER = new JRadioButton("MASTER", false);
		btn_cardtypeMASTER.setBounds(170, 10, 120, 30);
		panel.add(btn_cardtypeMASTER);

		ButtonGroup bt_group = new ButtonGroup();
		bt_group.add(btn_cardtypeVISA);
		bt_group.add(btn_cardtypeMASTER);

		JLabel lb_cardnum = new JLabel("- 카드번호 -");
		lb_cardnum.setBounds(20, 40, 100, 20);
		lb_cardnum.setFont(new Font("Vernada", Font.BOLD, 15));
		panel.add(lb_cardnum);

		JTextField tf_cardnum1 = new JTextField();
		tf_cardnum1.setBounds(20, 70, 50, 20);
		panel.add(tf_cardnum1);

		JTextField tf_cardnum2 = new JTextField();
		tf_cardnum2.setBounds(90, 70, 50, 20);
		panel.add(tf_cardnum2);

		JTextField tf_cardnum3 = new JTextField();
		tf_cardnum3.setBounds(160, 70, 50, 20);
		panel.add(tf_cardnum3);

		JTextField tf_cardnum4 = new JTextField();
		tf_cardnum4.setBounds(230, 70, 50, 20);
		panel.add(tf_cardnum4);

		JLabel lb_delimiter1 = new JLabel("-");
		lb_delimiter1.setBounds(76, 70, 5, 10);
		lb_delimiter1.setFont(new Font("Vernada", Font.BOLD, 15));
		panel.add(lb_delimiter1);

		JLabel lb_delimiter2 = new JLabel("-");
		lb_delimiter2.setBounds(146, 70, 5, 10);
		lb_delimiter2.setFont(new Font("Vernada", Font.BOLD, 15));
		panel.add(lb_delimiter2);

		JLabel lb_delimiter3 = new JLabel("-");
		lb_delimiter3.setBounds(216, 70, 5, 10);
		lb_delimiter3.setFont(new Font("Vernada", Font.BOLD, 15));
		panel.add(lb_delimiter3);

		JLabel lb_cardMMYY = new JLabel("- 년월(MMYY)-");
		lb_cardMMYY.setBounds(20, 100, 130, 20);
		lb_cardMMYY.setFont(new Font("Vernada", Font.BOLD, 15));
		panel.add(lb_cardMMYY);

		JTextField tf_cardMM = new JTextField();
		tf_cardMM.setBounds(20, 130, 50, 20);
		panel.add(tf_cardMM);

		JTextField tf_cardYY = new JTextField();
		tf_cardYY.setBounds(90, 130, 50, 20);
		panel.add(tf_cardYY);

		JLabel lb_delimiter5 = new JLabel("/");
		lb_delimiter5.setBounds(75, 130, 5, 20);
		lb_delimiter5.setFont(new Font("Vernada", Font.BOLD, 15));
		panel.add(lb_delimiter5);

		JLabel lb_cardCVC = new JLabel("- CVC -");
		lb_cardCVC.setBounds(155, 100, 100, 20);
		lb_cardCVC.setFont(new Font("Vernada", Font.BOLD, 15));
		panel.add(lb_cardCVC);

		JTextField tf_cardCVC = new JTextField();
		tf_cardCVC.setBounds(160, 130, 60, 20);
		panel.add(tf_cardCVC);

		JLabel lb_cardpw = new JLabel("- 비밀번호 -");
		lb_cardpw.setBounds(20, 156, 130, 20);
		lb_cardpw.setFont(new Font("Vernada", Font.BOLD, 15));
		panel.add(lb_cardpw);

		JTextField tf_cardpw = new JTextField();
		tf_cardpw.setBounds(20, 180, 260, 25);
		panel.add(tf_cardpw);

		JButton btn_payment = new JButton("결제");
		btn_payment.setFont(new Font("Vernada", Font.BOLD, 15));
		btn_payment.setBounds(20, 215, 180, 35);
		panel.add(btn_payment);

		JButton btn_paymentcancel = new JButton("취소");
		btn_paymentcancel.setFont(new Font("Vernada", Font.BOLD, 15));
		btn_paymentcancel.setBounds(210, 215, 70, 35);
		panel.add(btn_paymentcancel);

		btn_payment.addActionListener(new ActionListener() {

			// 정보가 들어가서 결제완료
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
				if(temp == "item")
				{
					if (btn_cardtypeVISA.isSelected() == true) {
						
						PaymentInfo.connect();
	
						String cardType = btn_cardtypeVISA.getText();
	
						String cardNum1 = tf_cardnum1.getText();
						String cardNum2 = tf_cardnum2.getText();
						String cardNum3 = tf_cardnum3.getText();
						String cardNum4 = tf_cardnum4.getText();
	
						String cardNum = cardNum1 + cardNum2 + cardNum3 + cardNum4;
	
						if (PaymentInfo.ItempayCheck(cardType, cardNum, Integer.parseInt(tf_cardYY.getText()),
								Integer.parseInt(tf_cardMM.getText()), Integer.parseInt(tf_cardCVC.getText()),
								Integer.parseInt(tf_cardpw.getText())) == true) {
							PaymentInfo.proNowNumUpdate();
							MenuList.initMenuList(ta_cart, lb_totalprice1);
							lb_totalprice1.setText("0");
							
							frame.dispose();
							JOptionPane.showMessageDialog(null, "결제가 완료되었습니다. ");
	
						}
					}else if (btn_cardtypeMASTER.isSelected() == true) {

					PaymentInfo.connect();

					String cardType = btn_cardtypeMASTER.getText();
					
					String cardNum1 = tf_cardnum1.getText();
					String cardNum2 = tf_cardnum2.getText();
					String cardNum3 = tf_cardnum3.getText();
					String cardNum4 = tf_cardnum4.getText();
					
					String cardNum = cardNum1 + cardNum2 + cardNum3 + cardNum4;


					if (PaymentInfo.ItempayCheck(cardType, cardNum, Integer.parseInt(tf_cardYY.getText()),
							Integer.parseInt(tf_cardMM.getText()), Integer.parseInt(tf_cardCVC.getText()),
							Integer.parseInt(tf_cardpw.getText())) == true) {
						PaymentInfo.proNowNumUpdate();
						MenuList.initMenuList(ta_cart, lb_totalprice1);
						lb_totalprice1.setText("0");
						
						frame.dispose();
						JOptionPane.showMessageDialog(null, "결제가 완료되었습니다. ");
						
					}

					
					
				}
				}
			}
		});

		btn_paymentcancel.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				frame.dispose();
			}
		});

		frame.add(panel);
		frame.setVisible(true);
	}

}
