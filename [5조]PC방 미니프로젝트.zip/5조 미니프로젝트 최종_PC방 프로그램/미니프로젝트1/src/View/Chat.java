package View;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.BevelBorder;
import javax.swing.border.Border;
import javax.swing.border.SoftBevelBorder;


import controller.Connchat;
public class Chat {
   public static JTextArea ta_chatview;
   public static JTextField tf_chatsend;
   public Chat(String type){

      JFrame frame = new JFrame();
      frame.setTitle("1 : 1 문의");
      frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // x 버튼 클릭시 Frame 닫기
      frame.setBounds(750,350,400,400);    // 생성 위치(x,y) 창 넓이( x,y)
      frame.setLayout(null);
      
      JPanel panel = new JPanel();
      panel.setBounds(0,0,400,400);
      panel.setLayout(null);
      
      JTextArea ta_chatview = new JTextArea("");
      ta_chatview.setBounds(0,0,383,200);
      ta_chatview.setBorder(new SoftBevelBorder(BevelBorder.RAISED, null, Color.RED, Color.RED, Color.RED));
      
      JScrollPane chatscroll = new JScrollPane(ta_chatview);
      chatscroll.setBounds(0, 0, 383,200);
      chatscroll.setBackground(Color.white);
      panel.add(chatscroll);

      ta_chatview.disable();
      
      
      JLabel lb_line = new JLabel("------------------------------------------------------------------------------------------------");
      lb_line.setBounds(0, 205, 400, 10);
      panel.add(lb_line);
      
      JLabel lb_message = new JLabel("Message ",JLabel.CENTER);
      lb_message.setBounds(0, 220, 100, 30);
      panel.add(lb_message);
      if(type == "member") {
         
      
      JButton btn_serveropen = new JButton("서버 연결");
      btn_serveropen.setBounds(270, 220, 110, 30);
      panel.add(btn_serveropen);
      btn_serveropen.addActionListener(new ActionListener() {
         
         @Override
         public void actionPerformed(ActionEvent e) {
            // TODO Auto-generated method stub
            if(type == "manager") 
            {
               Connchat.Connchatsetting(tf_chatsend, ta_chatview);
               Connchat.ServerstartService();
            }
            else if(type == "member") 
            {
               Connchat.Connchatsetting(tf_chatsend, ta_chatview);
               Connchat.ClientstartService();
            }
            
         }
      });
      }
      
      /*
      if(type == "manager") {
         JButton btn_serveropen = new JButton("서버 오픈");
         btn_serveropen.setBounds(270, 220, 110, 30);
         panel.add(btn_serveropen);
         btn_serveropen.addActionListener(new ActionListener() {
            
            @Override
            public void actionPerformed(ActionEvent e) {
               // TODO Auto-generated method stub
               Connchat.Connchatsetting(tf_chatsend, ta_chatview);
               Connchat.ServerstartService();
               
            }
         });
      }
      else if(type == "member" || type == "nonmember") {
         JButton btn_serverconnect = new JButton("서버 접속");
         btn_serverconnect.setBounds(270, 220, 110, 30);
         panel.add(btn_serverconnect);
         btn_serverconnect.addActionListener(new ActionListener() {
            
            @Override
            public void actionPerformed(ActionEvent e) {
               // TODO Auto-generated method stub
               Connchat.Connchatsetting(tf_chatsend, ta_chatview);
               Connchat.ClientstartService();
            }
         });
      }
      */
      
      JTextField tf_chatsend = new JTextField();
      tf_chatsend.setBounds(10,260,260,30);
      panel.add(tf_chatsend);
      
      JButton btn_send = new JButton("보내기");
      btn_send.setBounds(270, 260, 110, 30);
      panel.add(btn_send);
      btn_send.addActionListener(new ActionListener() {
         
         @Override
         public void actionPerformed(ActionEvent e) {
            // TODO Auto-generated method stub
            
            Connchat.ServersendMessage();
         }
      });
      
      JButton btn_exit = new JButton("Exit");
      btn_exit.setBounds(270, 310, 110, 40);
      panel.add(btn_exit);
      btn_exit.addActionListener(new ActionListener() {
         
         @Override
         public void actionPerformed(ActionEvent e) {
            // TODO Auto-generated method stub
            
            try {
               if(type == "manager") {
               Connchat.socket.close();
               Connchat.serverSocket.close();
               }
               else {
                  Connchat.ClientreceiveMessage();        
               }
            } catch (IOException e1) {
               // TODO Auto-generated catch block
               e1.printStackTrace();
            }
            frame.dispose();
         }
      });
      
      
      frame.add(panel);
      frame.setVisible(true);
      
      if(type == "manager") 
      {
         Connchat.Connchatsetting(tf_chatsend, ta_chatview);
         Connchat.ServerstartService();
      }
      else if(type == "member") 
      {
         Connchat.Connchatsetting(tf_chatsend, ta_chatview);
         Connchat.ClientstartService();
      }
      
   }
   
}