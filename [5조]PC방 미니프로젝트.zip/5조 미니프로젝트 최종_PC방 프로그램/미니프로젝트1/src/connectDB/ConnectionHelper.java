package connectDB;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectionHelper {
	
	public static Connection Connection(String dsn) {
		Connection conn = null;
		try {
			Class.forName("oracle.jdbc.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:orcl", "System" ,"oracle");
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			return conn;
		}
	}
}
