package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Iterator;

import connectDB.ConnectionHelper;

public class ProductListdata {
	static Connection conn = null;
	static ResultSet rs = null;
	static PreparedStatement pstmt = null;
	static Statement stmt  = null;
	public static HashMap<String, Integer> map; 
	public ProductListdata()  { 
		map = new HashMap<String, Integer>();
	}
	public static void connect()  {
		try {
		conn = ConnectionHelper.Connection("oracle");
		stmt = conn.createStatement();
		System.out.println("SQL 서버 연동 성공 !!");
		}catch (Exception e) {
			System.out.println("SQL 서버 연동 실패..");
		}
	}
	
	// 메뉴 이름, 메뉴 장바구니에 담은 갯수 맵에 저장
	public static void menuNamePrice() {
		connect();
		
		ProductListdata.map = new HashMap<String, Integer>();
		try {
			rs = stmt.executeQuery("select pro_name, pro_salesnum from product");
			while(rs.next()) {
				map.put(rs.getString(1), rs.getInt(2));
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	// 맵 키에 관한 값 받아오기
	public static int getmapValue(String pro_name) {
		return map.get(pro_name);
	}
}