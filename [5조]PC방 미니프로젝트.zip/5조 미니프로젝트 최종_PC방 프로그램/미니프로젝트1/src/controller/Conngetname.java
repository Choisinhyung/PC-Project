package controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import connectDB.ConnectionHelper;
//import model.PCVO;

public class Conngetname {
//	static PCVO pcvo = new PCVO();
	static Connection conn = null;
	static ResultSet rs = null;
	static PreparedStatement pstmt = null;
	static Statement stmt = null;
	
	
	public static void connect()  {
		try {
		conn = ConnectionHelper.Connection("oracle");
		stmt = conn.createStatement();
		System.out.println("SQL 서버 연동 성공 !!");
		}catch (Exception e) {
			System.out.println("SQL 서버 연동 실패..");
		}
	}
	
	// 유저 id 받아오기
	public static String Usergetname(String user_id)
	{
	
		
		try {
			rs = stmt.executeQuery("SELECT user_name FROM account WHERE user_id = '" +user_id +"'");
			rs.next();
			
				user_id = rs.getString(1);
			
			
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return user_id;
	}
}
