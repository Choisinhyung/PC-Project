package controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import connectDB.ConnectionHelper;
//import model.PCVO;

public class ConnUsersearch {
//	static PCVO pcvo = new PCVO();
	static Connection conn = null;
	static ResultSet rs = null;
	static PreparedStatement pstmt = null;
	static Statement stmt = null;

	static String[][] data = new String[150][7];

	static int i = 0;

	public static void connect() {
		try {
			conn = ConnectionHelper.Connection("oracle");
			stmt = conn.createStatement();
			System.out.println("SQL 서버 연동 성공 !!");
		} catch (Exception e) {
			System.out.println("SQL 서버 연동 실패..");
		}
	}

	// 회원정보 조회
	public static int connusersearch(JTable usertable, int index) {

		try {
			rs = stmt.executeQuery("SELECT * FROM account");
			DefaultTableModel model = (DefaultTableModel) usertable.getModel();

			if (index >= 0) {
				for (int j = index - 1; j >= 0; j--) {
					model.removeRow(j);
				}
				i = 0;
			}

			while (rs.next()) {

				String[] tempdata = new String[5];

				tempdata[0] = data[i][0] = rs.getString(1); // 테이블에 있는 인덱스 번호 or int gno = rs.getint("gno") 필드명
				tempdata[1] = data[i][0] = rs.getString(2);
				tempdata[2] = data[i][0] = rs.getString(3);
				tempdata[3] = data[i][0] = rs.getString(4);
				tempdata[4] = data[i][0] = rs.getString(5);

				model.addRow(tempdata);
				i++;

			}
			// JTable datatable = new JTable(data,column);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return i;
	}

}