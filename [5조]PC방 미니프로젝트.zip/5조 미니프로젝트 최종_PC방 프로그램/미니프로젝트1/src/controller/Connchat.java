package controller;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;

import javax.swing.JTextArea;
import javax.swing.JTextField;

public class Connchat {
	public static ServerSocket serverSocket;	// 서버 소켓
	public static Socket socket;		// 클라이언트 접속을 연결해주는 소켓
	
	private static DataInputStream dis;			// 입출력을 위한 변수
	private static DataOutputStream dos;
	
	private static boolean connectStatus;	//클라이언트 접속 여부 저장
	private static boolean stopSignal;//쓰레드 종료신호 저장
	
	public static JTextArea ta_area;		// 채팅 창
	public static JTextField tf_field;		// 채팅 입력 칸
	
	// 채팅 공간 설정
	public static void Connchatsetting(JTextField field,JTextArea area) {
		tf_field = field;
		ta_area = area;
	}

	// 서버 오픈
	public static void ServerstartService() {		// 서버 오픈
		try {
			ta_area.append("1:1 문의 준비중...\n");
			
			serverSocket = new ServerSocket(8888);		// 서버 소켓 생성
			ta_area.append("서비스 준비 완료\n");
			
			connectStatus = false;
			while(!connectStatus) {		// 현재 연결 상태가 true일 경우
				ta_area.append("고객 접속 대기중..\n");
				socket = serverSocket.accept();	// 고객 접속 대기
				ta_area.append("고객 접속완료.\n (" + socket.getInetAddress() + ")\n");
				break;
			}//end while
			new Thread(new Runnable() {	// 채팅 전달을 위한 스레드

				@Override
				public void run() {
					ServerreceiveMessage();
				}
			}).start();		// 스레드 실행
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	// 메시지 수신
	public static void ServerreceiveMessage() {
		try {
			while(!stopSignal) {	
				dis = new DataInputStream(socket.getInputStream());		// client가 입력한 메시지 읽어오기
				ta_area.append("고객 : " + dis.readUTF() + "\n");		// 채팅창에 출력
			}
			dis.close();
			socket.close();
		} catch (SocketException e) {		// 서버에서 socket을 닫았을 때
			ta_area.append("카운터와 접속 해제\n");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	// 메시지 송신
	public static void ServersendMessage() {
		try {
			String text = tf_field.getText();	// 입력한 문자열을 text에 저장
			ta_area.append(text + "\n");		// text를 채팅장에 출력
			
			if(text.equals("exit")) {	// exit입력 시
				stopSignal = true;
				dos.close();
				socket.close();
				System.exit(0);
			}else {
				dos = new DataOutputStream(socket.getOutputStream());	
				dos.writeUTF(text);		// 입력한 text를 네트워크로 흘려보내기
				tf_field.setText("");
				tf_field.requestFocus();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	//////////////////////////////////////////////////////////////client//////////////////////////////////
	public static void ClientstartService() {
		new Thread(new Runnable() {
	
			@Override
			public void run() {
				ClientreceiveMessage();
			}
		}).start();
	}
	public static void ClientconnectServer() {	// 서버와 연결
		try {
			socket = new Socket("localhost", 8888);
			connectStatus = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void ClientreceiveMessage() {
		ClientconnectServer();
		try {
			while(!stopSignal) {
				dis = new DataInputStream(socket.getInputStream());
				ta_area.append("카운터 : " + dis.readUTF() + "\n");
			}
			dis.close();
			socket.close();
		} catch(EOFException e){
			connectStatus=false;
		} catch(SocketException e) {
			ta_area.append("카운터와 연결 해제\n");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void sendMessage() {
		try {
			String text = tf_field.getText();
			ta_area.append(text + "\n");
			
			if(text.equals("exit")) {
				stopSignal = false;
				dos.close();
				socket.close();
				serverSocket.close();
			}else {
				dos = new DataOutputStream(socket.getOutputStream());
				dos.writeUTF(text);
				tf_field.setText("");
				tf_field.requestFocus();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
