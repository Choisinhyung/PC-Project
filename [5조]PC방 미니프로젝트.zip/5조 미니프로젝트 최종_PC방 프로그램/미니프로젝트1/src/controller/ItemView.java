package controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import connectDB.ConnectionHelper;
//import model.PCVO;

public class ItemView {
//	static PCVO pcvo = new PCVO();
	static Connection conn = null;
	static ResultSet rs = null;
	static PreparedStatement pstmt = null;
	static Statement stmt = null;

	static int[] temp = new int[3];
	static String[][] data = new String[150][7];
	static int i = 0;
	static String[] column = { "분류", "상품명", "상품가격", "현재수량", "판매수량", "원자재 가격", "상품별 매출" };

	public static void connect() {
		try {
			conn = ConnectionHelper.Connection("oracle");
			stmt = conn.createStatement();
			System.out.println("SQL 서버 연동 성공 !!");
		} catch (Exception e) {
			System.out.println("SQL 서버 연동 실패..");
		}
	}

	// 매니저 상품조회
	public static int[] itemview(JTable itemtable, int index) {

		try {
			rs = stmt.executeQuery("SELECT * FROM product");
			DefaultTableModel model = (DefaultTableModel) itemtable.getModel();

			model.setRowCount(0);

			temp[0] = 0;
			temp[1] = 0;
			temp[2] = 0;
			i = 0;

			while (rs.next()) {

				String[] tempdata = new String[7];

				tempdata[0] = data[i][0] = rs.getString(1); // 테이블에 있는 인덱스 번호 or int gno = rs.getint("gno") 필드명
				tempdata[1] = data[i][1] = rs.getString("pro_name");
				tempdata[2] = data[i][2] = rs.getString(3);
				tempdata[3] = data[i][3] = rs.getString(4);
				tempdata[4] = data[i][4] = rs.getString(5);
				tempdata[5] = data[i][5] = rs.getString(6);
				int sixdata = rs.getInt(3) * rs.getInt(5);
				temp[0] += rs.getInt(3) * rs.getInt(5);
				temp[1] += (rs.getInt(3) * rs.getInt(5)) - (rs.getInt(6) * rs.getInt(5));
				tempdata[6] = Integer.toString(sixdata);
				// tempdata[6] = (tempdata[2] * tempdata[4])-(tempdata[4]*tempdata[5]);

				model.addRow(tempdata);
				i++;
				temp[2] = i;

			}
			// JTable datatable = new JTable(data,column);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return temp;
	}
}
