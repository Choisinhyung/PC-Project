package controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import connectDB.ConnectionHelper;
//import model.PCVO;

public class ConnUserdel {
//	static PCVO pcvo = new PCVO();
	static Connection conn = null;
	static ResultSet rs = null;
	static PreparedStatement pstmt = null;
	static Statement stmt = null;
	
	public static void connect()  {
		try {
		conn = ConnectionHelper.Connection("oracle");
		stmt = conn.createStatement();
		System.out.println("SQL 서버 연동 성공 !!");
		}catch (Exception e) {
			System.out.println("SQL 서버 연동 실패..");
		}
	}
	
	// 회원정보 삭제
	public ConnUserdel(String id) {
		boolean flag =false;
		try {
			rs = stmt.executeQuery("SELECT count(*) FROM account WHERE user_id = '" + id + "'");
			
			rs.next();
			
			if ( rs.getInt(1) == 0 ) flag = false;
			else if ( rs.getInt(1) == 1 ) flag = true;
			
			
			System.out.println("end!!");
			
         
			
			//JTable datatable = new JTable(data,column);
		}catch (Exception e) {
			System.out.println("Exception1");
			e.printStackTrace();
		}
		if(flag ==true)
		{
			try {
				stmt.executeQuery("delete FROM account WHERE user_id = '" + id + "'");

				System.out.println("end!!");
				
	         
				
				//JTable datatable = new JTable(data,column);
			}catch (Exception e) {
				System.out.println("Exception1");
				e.printStackTrace();
			}
		}
	}
}
