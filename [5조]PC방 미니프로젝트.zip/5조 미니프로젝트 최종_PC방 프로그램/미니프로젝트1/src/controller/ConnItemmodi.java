package controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.table.DefaultTableModel;

import connectDB.ConnectionHelper;
//import model.PCVO;

public class ConnItemmodi {
//	static PCVO pcvo = new PCVO();
	static Connection conn = null;
	static ResultSet rs = null;
	static PreparedStatement pstmt = null;
	static Statement stmt = null;
	

	public static void connect()  {
		try {
		conn = ConnectionHelper.Connection("oracle");
		stmt = conn.createStatement();
		System.out.println("SQL 서버 연동 성공 !!");
		}catch (Exception e) {
			System.out.println("SQL 서버 연동 실패..");
		}
	}
	
	// 상품목록 수정을 위한 메소드
	public ConnItemmodi(String pro_name,String modi_type,String modi_name,String modi_price,String modi_nownum,
			String modi_salesnum,String modi_costprice) throws SQLException {
		if(pro_name.equals("")) pro_name = "-";	
		if(modi_type.equals("")) modi_type = "empty";	
		if(modi_name.equals("")) modi_name = "empty";	
		if(modi_price.equals("")) modi_price = "0";	
		if(modi_nownum.equals("")) modi_nownum = "0";	
		if(modi_salesnum.equals("")) modi_salesnum = "0";	
		if(modi_costprice.equals("")) modi_costprice = "0";	
		
		boolean flag = false;
		try {
			rs = stmt.executeQuery("SELECT count(*) FROM product WHERE pro_name = '" + pro_name + "'");
			rs.next();
			
			if ( rs.getInt(1) == 0 ) flag = false;
			else if ( rs.getInt(1) == 1 ) flag = true;
			
			
			System.out.println("end!!");

		}catch (Exception e) {
			System.out.println("Exception1");
			e.printStackTrace();
		}
		if(flag == true)
		{
			try {
				String sql = "update product set pro_type ='" +modi_type + "', pro_name ='" + modi_name +
						"', pro_price =" + modi_price +", pro_nowNum =" + modi_nownum 
						+  ", pro_salesNum =" + modi_salesnum +  ", pro_costprice =" + modi_costprice 
				+ " where pro_name = '" + pro_name + "'";	
				rs = stmt.executeQuery(sql);
				
				flag = false;

			}catch (Exception e) {
				System.out.println("Exception2");
				e.printStackTrace();
			}
		}
		
	}
}
