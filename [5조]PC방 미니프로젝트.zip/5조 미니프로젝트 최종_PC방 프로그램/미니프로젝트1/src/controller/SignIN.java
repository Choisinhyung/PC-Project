package controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import connectDB.ConnectionHelper;
//import model.PCVO;

public class SignIN {
//	static PCVO pcvo = new PCVO();
	static Connection conn = null;
	static ResultSet rs = null;
	static PreparedStatement pstmt = null;
	static Statement stmt = null;
	
	public static void connect()  {
		try {
		conn = ConnectionHelper.Connection("oracle");
		stmt = conn.createStatement();
		System.out.println("SQL 서버 연동 성공 !!");
		}catch (Exception e) {
			System.out.println("SQL 서버 연동 실패..");
		}
	}
	
	// 로그인을 위한 인증
	public static boolean LoginCheck( String user_type, String user_id, String user_pw) {
		boolean flag = false;
		try {
			rs = stmt.executeQuery("SELECT COUNT(*) FROM account WHERE user_id = '" +user_id + "' AND user_pw = '" + user_pw + "'");
			rs.next();
			if(rs.getInt(1) == 1) {
				flag = true;
			}
			else flag = false;
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		if(flag == true) {
		try {
			rs = stmt.executeQuery("SELECT user_type from account where user_id = '" + user_id  + "'");
			rs.next();
			if(rs.getString(1).equals(user_type)) {
				flag = true;
			}
			else flag = false;
		} catch (Exception e) {
			e.printStackTrace();
		}
		}
		return flag;
	}
	
	// 비회원 로그인
	public static boolean non_LoginCheck(String user_type ,String user_id) {
		boolean flag = false;
		try {
			rs = stmt.executeQuery("SELECT COUNT(*) FROM account WHERE user_id = '" + user_id + "' AND user_type = '" + user_type  + "'");
			rs.next();
			if(rs.getInt(1) == 1) flag = true;
			
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return flag;
	}
}
