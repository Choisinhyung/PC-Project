package controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import connectDB.ConnectionHelper;
//import model.PCVO;

public class ConnPwsearch {
//	static PCVO pcvo = new PCVO();
	static Connection conn = null;
	static ResultSet rs = null;
	static PreparedStatement pstmt = null;
	static Statement stmt = null;

	public static void connect()  {
		try {
		conn = ConnectionHelper.Connection("oracle");
		stmt = conn.createStatement();
		System.out.println("SQL 서버 연동 성공 !!");
		}catch (Exception e) {
			System.out.println("SQL 서버 연동 실패..");
		}
	}
	
	// 비밀번호 찾기
	public static String[] Pwsearch(String id,String name) {
		boolean flag =false;
		String[] result = new String[2];
		connect();
		try {
			rs = stmt.executeQuery("SELECT user_pw FROM account WHERE user_id = '" + id + "'" +" and "+ " user_name = '"+ name +"'");
			rs.next();
			
			result[0] = rs.getString(1);
			result[1] = "success";
			
			//JTable datatable = new JTable(data,column);
		}catch (Exception e) {
			System.out.println("Exception1");
			e.printStackTrace();
		}
		
		return result;
}
}
