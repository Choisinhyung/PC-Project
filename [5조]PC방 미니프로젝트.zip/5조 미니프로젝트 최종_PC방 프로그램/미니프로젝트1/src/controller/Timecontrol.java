package controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import connectDB.ConnectionHelper;
//import model.PCVO;

public class Timecontrol {
//	static PCVO pcvo = new PCVO();
	static Connection conn = null;
	static ResultSet rs = null;
	static PreparedStatement pstmt = null;
	static Statement stmt = null;
	
	
	//static String search_name;
	public static void connect()  {
		try {
		conn = ConnectionHelper.Connection("oracle");
		stmt = conn.createStatement();
		System.out.println("SQL 서버 연동 성공 !!");
		}catch (Exception e) {
			System.out.println("SQL 서버 연동 실패..");
		}
	}
	
	// 테이블에서 유저 시간 읽어오기
	public static int[] getTime(String user_id)
	{
		int[] timetemp = new int[3];
		
		try {
			rs = stmt.executeQuery("SELECT user_hour, user_minute FROM account WHERE user_id = '" +user_id +"'");
			rs.next();
			
				
				timetemp[0] = rs.getInt(1);
			
				timetemp[1] = rs.getInt(2);
				timetemp[2] = 1;
			
			
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return timetemp;
	}
	
	// 테이블에 유저 시간 업데이트
	public static int[] setTime(String user_id)
	{
		int[] timetemp = new int[3];
		
		try {
			rs = stmt.executeQuery("SELECT user_hour, user_minute FROM account WHERE user_id = '" +user_id +"'");
			rs.next();
			
				
				timetemp[0] = rs.getInt(1);
			
				timetemp[1] = rs.getInt(2);
				timetemp[2] = 1;
			
			
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return timetemp;
	}
	// 유저 시간 업데이트
	public static void updateTime(int h, int m , String user_id) {
		try {
			rs = stmt.executeQuery("update account set user_hour = " + h + " , user_minute = " + m + " where user_id = '" + user_id + "'");
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void updateTime(int h, int m) {
		try {
			rs = stmt.executeQuery("update account set user_hour = " + h + " , user_minute = " + m );
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
}
