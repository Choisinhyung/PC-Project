package controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import connectDB.ConnectionHelper;

import model.ProductListdata;


public class PaymentInfo {

	static Connection conn = null;
	static ResultSet rs = null;
	static PreparedStatement pstmt = null;
	static Statement stmt = null;

	public static void connect() {
		try {
			conn = ConnectionHelper.Connection("oracle");
			stmt = conn.createStatement();
			System.out.println("SQL 서버 연동 성공");
		} catch (Exception e) {
			System.out.println("SQL 서버 연동 실패");
		}
	}
	
	// 시간 충전 - 결제정보 확인 후 결제
	public static boolean TimepayCheck(String cardType, String cardNum, int year, int month, int cvc, int card_pw) {
		
		// db에 카드정보가 있으면 결제가 완료 되었습니다
		boolean flag = false;
		try {

			rs = stmt.executeQuery("select count(*) from pay where cardtype = '" + cardType + "' and cardnum = '"
					+ cardNum + "' and year = " + year + " and month = " + month + " and cvc = " + cvc
					+ " and card_pw = " + card_pw);

			rs.next();

			if (rs.getInt(1) == 1) {
				flag = true; //
			} else
				flag = false;
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (flag == true) {
			try {
				rs = stmt.executeQuery("select * from pay where cardtype = '" + cardType + "' and cardnum = '"
						+ cardNum + "' and year = " + year + " and month = " + month + " and cvc = " + cvc
						+ " and card_pw = " + card_pw);
				rs.next();
				if (rs.getString(1).equals(cardType) && rs.getString(2).equals(cardNum) && rs.getInt(3) == year
						&& rs.getInt(4) == month && rs.getInt(5) == cvc && rs.getInt(6) == card_pw) {
					flag = true;
				} else
					flag = false;
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return flag;
	}
	
	// 상품 결제 - 결제 정보 확인후 결제
	public static boolean ItempayCheck(String cardType, String cardNum, int year, int month, int cvc, int card_pw) {

		// db에 카드정보가 있으면 결제가 완료 되었습니다
		boolean flag = false;
		try {

			rs = stmt.executeQuery("select count(*) from pay where cardtype = '" + cardType + "' and cardnum = '"
					+ cardNum + "' and year = " + year + " and month = " + month + " and cvc = " + cvc
					+ " and card_pw = " + card_pw);

			rs.next();

			if (rs.getInt(1) == 1) {
				flag = true; //
			} else
				flag = false;
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (flag == true) {
			try {
				rs = stmt.executeQuery("select * from pay where cardtype = '" + cardType + "' and cardnum = '"
						+ cardNum + "' and year = " + year + " and month = " + month + " and cvc = " + cvc
						+ " and card_pw = " + card_pw);
				rs.next();
				if (rs.getString(1).equals(cardType) && rs.getString(2).equals(cardNum) && rs.getInt(3) == year
						&& rs.getInt(4) == month && rs.getInt(5) == cvc && rs.getInt(6) == card_pw) {
					flag = true;
				} else
					flag = false;
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return flag;
	}
	
	public static void TimeUpdate(String time, String name)
	{
		boolean flag = false;
		int nowtime = 0;
		try {

			rs = stmt.executeQuery("select user_hour from account where user_id = '" + name + "'");

			rs.next();
			nowtime =  rs.getInt(1);
			nowtime += Integer.parseInt(time);
			flag = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		if(flag ==true) {
			try {
				String sql = "update account set user_hour ='" + Integer.toString(nowtime) + "'" + "where user_id = '" + name + "'";
				rs = stmt.executeQuery(sql);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
	}
	
	
	// 상품 결제 후 재고 업데이트
	public static void proNowNumUpdate() {
		connect();
		String[] pro_name = new String[100];
		int count = 0;
		for (int i = 0; i < 100; i++) {
			if (MenuList.salesdata[i][0] == null) {		// 장바구니에 상품 명이 없을 때
				break;
			}
			count++;
		}
		for (int i = 0; i < 100; i++) {
			pro_name[i] = (String) MenuList.salesdata[i][0];		// 상품명을 pro_name에 저장
		}
		for (int i = 0; i < pro_name.length; i++) {
			for (int j = 0; j < count; j++) {
				if (i == j)
					continue;
				if (pro_name[i] != pro_name[j])		// 장바구니에 중복된 값이 들어가지 않도록 함
					pro_name[i] = (String) MenuList.salesdata[i][0];
				else
					pro_name[i] = null;
			}
		}
		int result = 0;
		try {
			for (int i = 0; i < pro_name.length; i++) {
				if (pro_name[i] == null)
					break;
				rs = stmt.executeQuery("update product set pro_salesnum = '" + ProductListdata.map.get(pro_name[i])
						+ "' where pro_name = '" + pro_name[i] + "'");			// 상품 팔린 개수 업데이트
			}
			for (int i = 0; i < 100; i++) {
				if (pro_name[i] == null)
					break;
				if ((int) MenuList.salesdata[i][2] == 100 && ProductListdata.map.containsKey(pro_name[i])) {	// 처음 팔린 상품일 경우
					result = ProductListdata.getmapValue(pro_name[i]) - (100 - (int) MenuList.salesdata[i][2]);	// 현재 팔린 개수
					MenuList.salesdata[i][2] = (int) MenuList.salesdata[i][2] - ProductListdata.getmapValue(pro_name[i]); //현재 개수 - 현재 팔린 개수를 salesdata에 입력
					ProductListdata.map.put(pro_name[i], (int) MenuList.salesdata[i][2]); // 현재 재고 업데이트

				} else if ((int) MenuList.salesdata[i][2] != 100 && ProductListdata.map.containsKey(pro_name[i])) { // 처음 팔린 상품이 아닐 경우
					result = ProductListdata.getmapValue(pro_name[i]) - (100 - (int) MenuList.salesdata[i][2]);	// 현재 팔린 개수
					MenuList.salesdata[i][2] = (int) MenuList.salesdata[i][2] - (result);	// 현재 개수 - 현재 팔린 개수(현재 팔린 개수만 현재 재고에서 빼주기 위해 result 빼기)
					ProductListdata.map.put(pro_name[i], (int) MenuList.salesdata[i][2]);	// 현재 재고 업데이트
				}
				rs = stmt.executeQuery("update product set pro_nownum = " + ProductListdata.map.get(pro_name[i])		// 오라클에 최종 업데이트
						+ " where pro_name = '" + pro_name[i] + "'");
				ProductListdata.map.put(pro_name[i], result);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
