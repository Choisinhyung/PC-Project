package controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Map;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import connectDB.ConnectionHelper;
import model.ProductListdata;

public class MenuList {
	static Connection conn = null;
	static ResultSet rs = null;
	static PreparedStatement pstmt = null;
	static Statement stmt = null;
	static int i = 0;
	static Object[][] salesdata = new Object[100][3];

	public static void connect() {
		try {
			conn = ConnectionHelper.Connection("oracle");
			stmt = conn.createStatement();
			System.out.println("SQL 서버 연동 성공 !!");
		} catch (Exception e) {
			System.out.println("SQL 서버 연동 실패..");
		}
	}
	/*
	 * 1. 추가 2. 초기화
	 * 
	 * 3. 총금액
	 */
	
	//메뉴 장바구니에 담긴 리스트 받아오기
	public static int SelectMenuList(JTable ta_cart, String pro_name, int total_price) {
		connect();
		try {

			switch (JOptionPane.showConfirmDialog(null, "[" + pro_name + "]을 선택하셨습니다. 장바구니에 담을까요?", "상품 담기",
					JOptionPane.YES_NO_OPTION)) {
			case 0: // 확인
				total_price = 0;
				DefaultTableModel m = (DefaultTableModel) ta_cart.getModel();
				rs = stmt.executeQuery(
						"SELECT pro_name, pro_price, pro_nownum from product where pro_name = '" + pro_name + "'");
				while (rs.next()) {
					Object[] tempdata = new Object[2];
					tempdata[0] = salesdata[i][0] = rs.getString(1);
					tempdata[1] = salesdata[i][1] = rs.getInt(2);
					salesdata[i][2] = rs.getInt(3);
					i++;
					m.addRow(tempdata);
				}
				for (int z = 0; z < i; z++) {
					total_price += (int) salesdata[z][1];
				}
				return total_price;
			case 1:
				return total_price; // 아니오
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return total_price;
	}
	
	// 메뉴 장바구니 리스트 초기화, 금액 초기화, 맵 초기화
	public static void initMenuList(JTable ta_cart, JLabel total) {
		DefaultTableModel m = (DefaultTableModel) ta_cart.getModel();
		for (int i = 0; i < salesdata.length; i++) {
			salesdata[i][0] = null;
			salesdata[i][1] = 0;
			salesdata[i][2] = 0;
		}
		ProductListdata.menuNamePrice();
		m.setRowCount(0);
		
	}
	
	// 장바구니에 담은 상품명과 값 하나씩 증가 시켜서 맵에 삽입
	public static void Countmenu(String pro_name) {
		if (ProductListdata.map == null) {
			ProductListdata.menuNamePrice();
		}
		int result = ProductListdata.getmapValue(pro_name);
		for (int i = 0; i < ProductListdata.map.size(); i++) {
			if (ProductListdata.map.containsKey(pro_name)) {
				result++;
				break;
			}
		}
		ProductListdata.map.put(pro_name, result);
//		System.out.println(pro_name + ": " + productListdata.map.get(pro_name));
	}
}
