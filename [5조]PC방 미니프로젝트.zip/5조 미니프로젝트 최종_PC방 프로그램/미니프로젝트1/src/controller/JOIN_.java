package controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JOptionPane;

import connectDB.CloseHelper;
import connectDB.ConnectionHelper;
//import model.PCVO;

public class JOIN_ {

	static Connection conn = null;
	static ResultSet rs = null;
	static PreparedStatement pstmt = null;
	static Statement stmt = null;

	public static void connect() {
		try {
			conn = ConnectionHelper.Connection("oracle");
			stmt = conn.createStatement();
			System.out.println("SQL 서버 연동 성공 !!");
		} catch (Exception e) {
			System.out.println("SQL 서버 연동 실패..");
		}
	}

	// close
	public static void close() {
		CloseHelper.close(conn);
		CloseHelper.close(pstmt);
		CloseHelper.close(rs);
		CloseHelper.close(pstmt);
	}

	// 회원가입
	public static void Join_request(String user_name, String user_id, String user_pw) {
		boolean flag = false;
		boolean nullflag = true;
		if (user_name.equals("")) {
			JOptionPane.showMessageDialog(null, "이름을 입력하지 않았습니다.");
			nullflag = false;
		} else if (user_id.equals("")) {
			JOptionPane.showMessageDialog(null, "아이디을 입력하지 않았습니다.");
			nullflag = false;
		} else if (user_pw.equals("")) {
			JOptionPane.showMessageDialog(null, "비밀번호를 입력하지 않았습니다.");
			nullflag = false;
		}
		try {
			if (flag == false && nullflag == true) {
				rs = stmt.executeQuery("select count(*) from account where user_id = '" + user_id + "'");
				rs.next();
				if (rs.getInt(1) == 1) {
					flag = false;
					JOptionPane.showMessageDialog(null, "이미 사용중인 아이디 입니다.");

				} else {
					flag = true;
				}
			}
			if (flag == true && nullflag == true) {
				pstmt = conn.prepareStatement("insert into account values(?,?,?,?,?,?)");
				pstmt.setString(1, "member"); // count함수 만들기 select
				pstmt.setString(2, user_name);
				pstmt.setString(3, user_id);
				pstmt.setString(4, user_pw);
				pstmt.setString(5, "0");
				pstmt.setString(6, "30");
				pstmt.executeUpdate();
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
