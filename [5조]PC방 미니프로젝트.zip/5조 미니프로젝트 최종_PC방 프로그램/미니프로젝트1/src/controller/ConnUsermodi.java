package controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import connectDB.ConnectionHelper;
//import model.PCVO;

public class ConnUsermodi {
//	static PCVO pcvo = new PCVO();
	static Connection conn = null;
	static ResultSet rs = null;
	static PreparedStatement pstmt = null;
	static Statement stmt = null;
	

	public static void connect()  {
		try {
		conn = ConnectionHelper.Connection("oracle");
		stmt = conn.createStatement();
		System.out.println("SQL 서버 연동 성공 !!");
		}catch (Exception e) {
			System.out.println("SQL 서버 연동 실패..");
		}
	}	
	// 회원정보 수정 메소드
	public ConnUsermodi(String prev_id,String modi_type,String modi_name,String modi_id,String modi_pw) 
	{
		
		if(prev_id.equals("")) prev_id = "-";	
		if(modi_type.equals("")) modi_type = "empty";	
		if(modi_name.equals("")) modi_name = "empty";	
		if(modi_id.equals("")) modi_id = "empty";	
		if(modi_pw.equals("")) modi_pw = "empty";	
		
		
		
		boolean flag = false;
		try {
			rs = stmt.executeQuery("SELECT count(*) FROM account WHERE user_id = '" + prev_id + "'");
			rs.next();
			
			if ( rs.getInt(1) == 0 ) flag = false;
			else if ( rs.getInt(1) == 1 ) flag = true;
			
			
			System.out.println("end!!");
			
	     
			
			//JTable datatable = new JTable(data,column);
		}catch (Exception e) {
			System.out.println("Exception1");
			e.printStackTrace();
		}
		if(flag == true)
		{
			try {
				String sql = "update account set user_type ='" +modi_type +"', user_id ='" + modi_id+ 
						"', user_name ='" + modi_name  +"', user_pw ='" + modi_pw 
						+  "' where user_id = '" + prev_id + "'";	
				rs = stmt.executeQuery(sql);
				
				flag = false;

			}catch (Exception e) {
				System.out.println("Exception2");
				e.printStackTrace();
			}
		}
		
	}
	
}
