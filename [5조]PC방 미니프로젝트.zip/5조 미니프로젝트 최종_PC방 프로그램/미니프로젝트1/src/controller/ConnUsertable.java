package controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import connectDB.ConnectionHelper;
//import model.PCVO;

public class ConnUsertable {
//	static PCVO pcvo = new PCVO();
	static Connection conn = null;
	static ResultSet rs = null;
	static PreparedStatement pstmt = null;
	static Statement stmt = null;

	static String[][] data = new String[150][7];

	static int i = 0;

	public static void connect() {
		try {
			conn = ConnectionHelper.Connection("oracle");
			stmt = conn.createStatement();
			System.out.println("SQL 서버 연동 성공 !!");
		} catch (Exception e) {
			System.out.println("SQL 서버 연동 실패..");
		}
	}

	public static int connusertable(JTable usertable, int index) {

		try {
			rs = stmt.executeQuery("SELECT * FROM account");
			DefaultTableModel model = (DefaultTableModel) usertable.getModel();

			model.setRowCount(0);
			i = 0;

			while (rs.next()) {

				String[] tempdata = new String[5];

				tempdata[0] = data[i][0] = rs.getString(1); // 테이블에 있는 인덱스 번호 or int gno = rs.getint("gno") 필드명
				tempdata[1] = data[i][0] = rs.getString(2);
				tempdata[2] = data[i][0] = rs.getString(3);
				tempdata[3] = data[i][0] = rs.getString(4);
				tempdata[4] = data[i][0] = rs.getString(5) + " : " + rs.getString(6);

				model.addRow(tempdata);
				i++;

			}
			// JTable datatable = new JTable(data,column);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return i;
	}

	public static int connusertable(JTable usertable, String searchid, int index) {

		try {
			rs = stmt.executeQuery("SELECT * FROM account where user_id = '" + searchid + "'");
			DefaultTableModel model = (DefaultTableModel) usertable.getModel();

			if (index >= 0) {
				for (int j = index - 1; j >= 0; j--) {
					model.removeRow(j);
				}
				i = 0;
			}

			while (rs.next()) {

				String[] tempdata = new String[5];

				tempdata[0] = rs.getString("user_type"); // 테이블에 있는 인덱스 번호 or int gno = rs.getint("gno") 필드명
				tempdata[1] = rs.getString("user_name");
				tempdata[2] = rs.getString("user_id");
				tempdata[3] = rs.getString("user_pw");
				tempdata[4] = rs.getString("user_hour") + " : " + rs.getString("user_minute");

				model.addRow(tempdata);
				i++;

			}
			// JTable datatable = new JTable(data,column);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return i;
	}

}
